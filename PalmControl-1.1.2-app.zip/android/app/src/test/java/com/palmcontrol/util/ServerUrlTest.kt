package com.palmcontrol.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ServerUrlTest {

    @Test
    fun `adds scheme and default path`() {
        assertEquals("ws://192.168.1.10:8080/ws", ServerUrl.normalize("192.168.1.10:8080"))
        assertEquals("ws://example.com/ws", ServerUrl.normalize("example.com"))
    }

    @Test
    fun `keeps explicit ws path`() {
        assertEquals("ws://10.0.0.5:9000/ws", ServerUrl.normalize("ws://10.0.0.5:9000/ws"))
        assertEquals("wss://relay.example.com/custom", ServerUrl.normalize("wss://relay.example.com/custom"))
    }

    @Test
    fun `converts http schemes`() {
        assertEquals("ws://relay.example.com/ws", ServerUrl.normalize("http://relay.example.com"))
        assertEquals("wss://relay.example.com/ws", ServerUrl.normalize("https://relay.example.com"))
        assertEquals("ws://relay.example.com:8080/ws", ServerUrl.normalize("http://relay.example.com:8080/"))
    }

    @Test
    fun `rejects invalid input`() {
        assertNull(ServerUrl.normalize(""))
        assertNull(ServerUrl.normalize("   "))
        assertNull(ServerUrl.normalize("ftp://example.com"))
        assertNull(ServerUrl.normalize("ws://"))
    }
}
