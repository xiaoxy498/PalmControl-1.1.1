package com.palmcontrol.host

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class StreamPresetsTest {

    @Test
    fun `scales down to target width`() {
        assertArrayEquals(intArrayOf(720, 1600), StreamPresets.outputSize(1080, 2400, 720))
        assertArrayEquals(intArrayOf(480, 1066), StreamPresets.outputSize(1080, 2400, 480))
    }

    @Test
    fun `does not upscale`() {
        assertArrayEquals(intArrayOf(720, 1600), StreamPresets.outputSize(720, 1600, 1080))
    }

    @Test
    fun `creates presets`() {
        assertEquals(StreamConfig(480, 45, 10), StreamPresets.create(0, 0))
        assertEquals(StreamConfig(720, 62, 15), StreamPresets.create(1, 1))
        assertEquals(StreamConfig(1080, 78, 20), StreamPresets.create(2, 2))
    }

    @Test
    fun `clamps out of range indexes`() {
        assertEquals(StreamConfig(1080, 78, 20), StreamPresets.create(9, 9))
        assertEquals(StreamConfig(480, 45, 10), StreamPresets.create(-3, -3))
    }
}
