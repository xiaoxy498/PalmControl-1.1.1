package com.palmcontrol.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.palmcontrol.R
import com.palmcontrol.util.ChatAttachment

object ChatAttachmentView {

    fun create(
        context: Context,
        attachment: ChatAttachment,
        isUser: Boolean,
        onSave: (ChatAttachment) -> Unit
    ): View {
        val bubble = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 10), dp(context, 8), dp(context, 10), dp(context, 8))
            setBackgroundResource(if (isUser) R.drawable.bg_bubble_user else R.drawable.bg_bubble_ai)
        }

        if (attachment.isImage) {
            val bitmap = runCatching {
                BitmapFactory.decodeByteArray(attachment.bytes(), 0, attachment.bytes().size)
            }.getOrNull()
            if (bitmap != null) {
                val image = ImageView(context).apply {
                    setImageBitmap(bitmap)
                    adjustViewBounds = true
                    maxWidth = dp(context, 230)
                    maxHeight = dp(context, 260)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setOnClickListener { showPreview(context, bitmap) }
                }
                bubble.addView(
                    image,
                    LinearLayout.LayoutParams(dp(context, 220), LinearLayout.LayoutParams.WRAP_CONTENT)
                )
            }
        }

        val caption = TextView(context).apply {
            text = if (attachment.isImage) {
                attachment.name
            } else {
                "${attachment.name}\n${formatSize(attachment.bytes().size)} · 点击保存"
            }
            setTextColor(ContextCompat.getColor(context, R.color.text_primary))
            textSize = 12f
            setPadding(0, if (attachment.isImage) dp(context, 6) else dp(context, 2), 0, 0)
            if (!attachment.isImage) setOnClickListener { onSave(attachment) }
        }
        bubble.addView(caption)
        if (!attachment.isImage) bubble.setOnClickListener { onSave(attachment) }

        return LinearLayout(context).apply {
            gravity = if (isUser) Gravity.END else Gravity.START
            addView(
                bubble,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = dp(context, 8)
                    marginStart = if (isUser) dp(context, 40) else 0
                    marginEnd = if (isUser) 0 else dp(context, 40)
                }
            )
        }
    }

    private fun showPreview(context: Context, bitmap: android.graphics.Bitmap) {
        val image = ImageView(context).apply {
            setImageBitmap(bitmap)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(context, 8), dp(context, 8), dp(context, 8), dp(context, 8))
        }
        MaterialAlertDialogBuilder(context)
            .setView(image)
            .setPositiveButton(R.string.close, null)
            .show()
    }

    private fun formatSize(bytes: Int): String = when {
        bytes >= 1024 * 1024 -> String.format("%.1f MB", bytes / 1024f / 1024f)
        bytes >= 1024 -> String.format("%.1f KB", bytes / 1024f)
        else -> "$bytes B"
    }

    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()
}
