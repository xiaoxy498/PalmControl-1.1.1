package com.palmcontrol.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.palmcontrol.BuildConfig
import com.palmcontrol.R
import com.palmcontrol.databinding.ActivityMainBinding
import com.palmcontrol.databinding.DialogPairPinBinding
import com.palmcontrol.util.AccountApi
import com.palmcontrol.util.AccountStore
import com.palmcontrol.util.Prefs
import com.palmcontrol.util.ServerUrl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var registerMode = false
    private var sessionChecked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupBottomNav()
        setupRemotePage()
        setupDevicesPage()
        setupProfilePage()
        showTab(Tab.REMOTE)
    }

    override fun onResume() {
        super.onResume()
        refreshRemotePage()
        refreshDevicesPage()
        refreshProfilePage()
        checkBannedState()
    }

    // ---------------- 底部导航 ----------------

    private enum class Tab { REMOTE, DEVICES, PROFILE }

    private fun setupBottomNav() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.tab_remote -> showTab(Tab.REMOTE)
                R.id.tab_devices -> showTab(Tab.DEVICES)
                R.id.tab_profile -> showTab(Tab.PROFILE)
            }
            true
        }
    }

    private fun showTab(tab: Tab) {
        binding.pageRemote.root.isVisible = tab == Tab.REMOTE
        binding.pageDevices.root.isVisible = tab == Tab.DEVICES
        binding.pageProfile.root.isVisible = tab == Tab.PROFILE

        binding.tvTabTitle.setText(
            when (tab) {
                Tab.REMOTE -> R.string.tab_remote
                Tab.DEVICES -> R.string.tab_devices
                Tab.PROFILE -> R.string.tab_profile
            }
        )
        binding.tvTabSubtitle.setText(
            when (tab) {
                Tab.REMOTE -> R.string.tab_remote_subtitle
                Tab.DEVICES -> R.string.tab_devices_subtitle
                Tab.PROFILE -> R.string.tab_profile_subtitle
            }
        )
        if (tab == Tab.PROFILE) refreshProfilePage()
        if (tab == Tab.DEVICES) refreshDevicesPage()
    }

    // ---------------- 远程协助 ----------------

    private fun setupRemotePage() {
        binding.pageRemote.btnStartRemote.setOnClickListener {
            val code = binding.pageRemote.etCode.text?.toString()?.trim().orEmpty()
            if (code.length != 6 || code.any { !it.isDigit() }) {
                toast(getString(R.string.code_invalid))
                return@setOnClickListener
            }
            promptPin(code)
        }
    }

    private fun promptPin(code: String) {
        val dialogBinding = DialogPairPinBinding.inflate(layoutInflater)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.pin_dialog_title)
            .setView(dialogBinding.root)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.pin_dialog_start) { _, _ ->
                connect(code, dialogBinding.etPin.text?.toString()?.trim().orEmpty())
            }
            .show()
    }

    private fun connect(code: String, pin: String) {
        startActivity(
            Intent(this, ControllerActivity::class.java)
                .putExtra(ControllerActivity.EXTRA_CODE, code)
                .putExtra(ControllerActivity.EXTRA_PIN, pin)
                .putExtra(ControllerActivity.EXTRA_AUTO_CONNECT, true)
        )
    }

    private fun refreshRemotePage() {
        val server = Prefs.load(this).serverUrl.ifBlank { getString(R.string.server_not_set) }
        binding.pageRemote.tvServerSummary.text = getString(R.string.server_summary, server)
    }

    // ---------------- 我的设备 ----------------

    private fun setupDevicesPage() {
        binding.pageDevices.btnStartShare.setOnClickListener {
            if (!Prefs.isShareAllowed(this)) {
                MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.share_disabled_title)
                    .setMessage(R.string.share_disabled_message)
                    .setNegativeButton(R.string.cancel, null)
                    .setPositiveButton(R.string.go_settings) { _, _ ->
                        startActivity(Intent(this, SettingsActivity::class.java))
                    }
                    .show()
                return@setOnClickListener
            }
            startActivity(Intent(this, HostActivity::class.java))
        }
    }

    private fun refreshDevicesPage() {
        val config = Prefs.load(this)
        val name = config.deviceName.ifBlank { Build.MODEL }
        binding.pageDevices.tvDeviceName.text = name
        binding.pageDevices.tvDeviceAvatar.text = name.take(1).uppercase()
        binding.pageDevices.tvDeviceMeta.text =
            getString(R.string.device_meta, Build.VERSION.RELEASE, config.serverUrl)

        val allowed = Prefs.isShareAllowed(this)
        binding.pageDevices.tvShareStatus.setText(
            if (allowed) R.string.device_share_allowed else R.string.device_share_blocked
        )
        binding.pageDevices.tvShareStatus.setTextColor(
            ContextCompat.getColor(
                this,
                if (allowed) R.color.success_green else R.color.warning_amber
            )
        )
    }

    // ---------------- 我的 ----------------

    private fun setupProfilePage() {
        binding.pageProfile.tvVersion.text =
            getString(R.string.version_label, BuildConfig.VERSION_NAME)

        binding.pageProfile.btnAuthSwitch.setOnClickListener {
            registerMode = !registerMode
            renderAuthMode()
        }
        binding.pageProfile.btnAuthSubmit.setOnClickListener { submitAuth() }
        binding.pageProfile.rowSupport.setOnClickListener {
            val target = if (Prefs.currentUser(this) == ADMIN_USER) {
                AdminSupportActivity::class.java
            } else {
                SupportActivity::class.java
            }
            startActivity(Intent(this, target))
        }
        binding.pageProfile.rowMessages.setOnClickListener {
            val user = Prefs.currentUser(this)
            when {
                user == null -> toast(getString(R.string.messages_login_required))
                user == ADMIN_USER -> toast(getString(R.string.messages_admin_hint))
                Prefs.authToken(this) == null -> toast(getString(R.string.messages_login_required))
                else -> startActivity(Intent(this, MessagesActivity::class.java))
            }
        }
        binding.pageProfile.rowSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.pageProfile.btnLogout.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.profile_logout)
                .setMessage(R.string.logout_message)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.profile_logout) { _, _ ->
                    Prefs.setCurrentUser(this, null)
                    refreshProfilePage()
                    toast(getString(R.string.logout_done))
                }
                .show()
        }
        renderAuthMode()
    }

    private fun renderAuthMode() {
        val page = binding.pageProfile
        page.tvAuthTitle.setText(if (registerMode) R.string.auth_register else R.string.auth_login)
        page.btnAuthSubmit.setText(if (registerMode) R.string.auth_register else R.string.auth_login)
        page.btnAuthSwitch.setText(
            if (registerMode) R.string.auth_switch_to_login else R.string.auth_switch_to_register
        )
        page.tilConfirm.isVisible = registerMode
        page.tilEmail.isVisible = registerMode
        page.tvAuthError.isVisible = false
    }

    private fun submitAuth() {
        val page = binding.pageProfile
        val username = page.etUsername.text?.toString()?.trim().orEmpty()
        val password = page.etPassword.text?.toString().orEmpty()
        val confirm = page.etConfirm.text?.toString().orEmpty()
        val email = page.etEmail.text?.toString()?.trim().orEmpty()

        page.tvAuthError.isVisible = false

        if (username.length !in 3..20 || username.any { it.isWhitespace() }) {
            showAuthError(getString(R.string.auth_error_username))
            return
        }
        if (password.length < 6) {
            showAuthError(getString(R.string.auth_error_password))
            return
        }

        val base = ServerUrl.toHttpBase(Prefs.load(this).serverUrl)
        if (base == null) {
            showAuthError(getString(R.string.auth_error_network))
            return
        }

        if (registerMode) {
            if (username.equals(ADMIN_USER, ignoreCase = true)) {
                showAuthError(getString(R.string.auth_error_admin_reserved))
                return
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                showAuthError(getString(R.string.auth_error_email))
                return
            }
            if (password != confirm) {
                showAuthError(getString(R.string.auth_error_confirm))
                return
            }
            page.btnAuthSubmit.isEnabled = false
            lifecycleScope.launch {
                val outcome = AccountApi.register(base, username, email, password)
                page.btnAuthSubmit.isEnabled = true
                when (outcome) {
                    is AccountApi.Outcome.Success -> {
                        applyAuth(outcome)
                        toast(getString(R.string.auth_register_done))
                    }
                    is AccountApi.Outcome.UserExists ->
                        showAuthError(getString(R.string.auth_error_exists))
                    is AccountApi.Outcome.Failure ->
                        showAuthError(authFailureText(outcome.reason))
                    else -> showAuthError(getString(R.string.auth_error_network))
                }
            }
        } else {
            // 内置管理员账号
            if (username.equals(ADMIN_USER, ignoreCase = true)) {
                if (password != ADMIN_PASSWORD) {
                    showAuthError(getString(R.string.auth_error_admin_password))
                    return
                }
                Prefs.setCurrentUser(this, ADMIN_USER)
                page.etPassword.setText("")
                refreshProfilePage()
                toast(getString(R.string.auth_login_done))
                return
            }
            page.btnAuthSubmit.isEnabled = false
            lifecycleScope.launch {
                var outcome = AccountApi.login(base, username, password)
                if (outcome is AccountApi.Outcome.InvalidCredentials) {
                    // 旧版本的本地账号：密码正确就自动迁移到服务端
                    val legacyOk = withContext(Dispatchers.Default) {
                        AccountStore.login(this@MainActivity, username, password) is
                            AccountStore.Result.Success
                    }
                    if (legacyOk) {
                        outcome = AccountApi.register(base, username, "", password, migrate = true)
                        if (outcome is AccountApi.Outcome.UserExists) {
                            outcome = AccountApi.login(base, username, password)
                        }
                    }
                }
                page.btnAuthSubmit.isEnabled = true
                when (outcome) {
                    is AccountApi.Outcome.Success -> {
                        applyAuth(outcome)
                        toast(
                            getString(
                                if (outcome.banned) R.string.auth_banned_notice
                                else R.string.auth_login_done
                            )
                        )
                    }
                    is AccountApi.Outcome.InvalidCredentials ->
                        showAuthError(getString(R.string.auth_error_wrong))
                    is AccountApi.Outcome.Failure ->
                        showAuthError(authFailureText(outcome.reason))
                    else -> showAuthError(getString(R.string.auth_error_network))
                }
            }
        }
    }

    private fun authFailureText(reason: String): String = getString(
        if (reason == "http_404" || reason == "not_found") R.string.auth_error_server_old
        else R.string.auth_error_network
    )

    private fun applyAuth(outcome: AccountApi.Outcome.Success) {
        val page = binding.pageProfile
        Prefs.setCurrentUser(this, outcome.username.ifBlank { page.etUsername.text?.toString() })
        Prefs.setAuthToken(this, outcome.token)
        registerMode = false
        page.etPassword.setText("")
        page.etConfirm.setText("")
        page.etEmail.setText("")
        renderAuthMode()
        refreshProfilePage()
    }

    private fun showAuthError(message: String) {
        binding.pageProfile.tvAuthError.text = message
        binding.pageProfile.tvAuthError.isVisible = true
    }

    private fun refreshProfilePage() {
        val page = binding.pageProfile
        val user = Prefs.currentUser(this)

        if (user == null) {
            page.authCard.isVisible = true
            page.profilePanel.isVisible = false
            renderAuthMode()
        } else {
            page.authCard.isVisible = false
            page.profilePanel.isVisible = true
            page.tvUsername.text = user
            page.tvAvatar.text = user.take(1).uppercase()
            page.tvSupportLabel.setText(
                if (user == ADMIN_USER) R.string.profile_support_admin else R.string.profile_support
            )
            refreshMessagesMeta()
        }
    }

    /** 后台发出的消息数，显示在“消息”右侧。 */
    private fun refreshMessagesMeta() {
        val page = binding.pageProfile
        val user = Prefs.currentUser(this)
        val token = Prefs.authToken(this)
        if (user == null || user == ADMIN_USER || token == null) {
            page.tvMessagesMeta.setText(R.string.messages_guest)
            return
        }
        val base = ServerUrl.toHttpBase(Prefs.load(this).serverUrl) ?: return
        lifecycleScope.launch {
            when (val inbox = AccountApi.inbox(base, token)) {
                is AccountApi.Inbox.Success -> page.tvMessagesMeta.text =
                    if (inbox.unread > 0) getString(R.string.messages_unread_count, inbox.unread) else ""
                else -> Unit
            }
        }
    }

    /** 每次进入 App 检查一次会话；封禁不再强制下线，只提示远控与客服被限制。 */
    private fun checkBannedState() {
        val user = Prefs.currentUser(this) ?: return
        if (user == ADMIN_USER || sessionChecked) return
        val token = Prefs.authToken(this) ?: return
        val base = ServerUrl.toHttpBase(Prefs.load(this).serverUrl) ?: return
        sessionChecked = true
        lifecycleScope.launch {
            when (val outcome = AccountApi.checkSession(base, token)) {
                is AccountApi.Outcome.Success -> {
                    if (outcome.banned) toast(getString(R.string.auth_banned_notice))
                }
                is AccountApi.Outcome.InvalidCredentials -> {
                    Prefs.setCurrentUser(this@MainActivity, null)
                    sessionChecked = false
                    refreshProfilePage()
                    toast(getString(R.string.messages_session_expired))
                }
                else -> Unit
            }
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val ADMIN_USER = "ADMIN"
        const val ADMIN_PASSWORD = "ADMIN123"
    }
}
