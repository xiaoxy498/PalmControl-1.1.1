package com.palmcontrol.net

import org.json.JSONArray
import org.json.JSONObject

data class NormalizedPoint(val x: Float, val y: Float)

/** 控制端采集到的一笔手势，坐标已归一化到画面 0..1。 */
data class StrokePoint(
    val points: List<NormalizedPoint>,
    val startTimeMs: Long,
    val durationMs: Long
)

object Messages {
    const val TYPE = "type"

    // 客户端 -> 服务器
    const val HOST_REGISTER = "host.register"
    const val CONTROLLER_JOIN = "controller.join"
    const val JOIN_DECISION = "join.decision"

    // 服务器 -> 客户端
    const val HOST_REGISTERED = "host.registered"
    const val JOIN_REQUEST = "join.request"
    const val JOIN_PENDING = "join.pending"
    const val PAIRED = "paired"
    const val PEER_LEFT = "peer.left"
    const val ERROR = "error"

    // 会话内
    const val VIDEO_CONFIG = "video.config"
    const val INPUT_GESTURE = "input.gesture"
    const val INPUT_KEY = "input.key"
    const val INPUT_TEXT = "input.text"
    const val SESSION_END = "session.end"

    fun hostRegister(deviceName: String, pin: String?): String =
        JSONObject()
            .put(TYPE, HOST_REGISTER)
            .put("deviceName", deviceName)
            .put("pin", pin.orEmpty())
            .toString()

    fun controllerJoin(code: String, pin: String?, deviceName: String): String =
        JSONObject()
            .put(TYPE, CONTROLLER_JOIN)
            .put("code", code)
            .put("pin", pin.orEmpty())
            .put("deviceName", deviceName)
            .toString()

    fun joinDecision(controllerId: String, allow: Boolean, reason: String?): String =
        JSONObject()
            .put(TYPE, JOIN_DECISION)
            .put("controllerId", controllerId)
            .put("allow", allow)
            .put("reason", reason.orEmpty())
            .toString()

    fun videoConfig(width: Int, height: Int, fps: Int, quality: Int): String =
        JSONObject()
            .put(TYPE, VIDEO_CONFIG)
            .put("width", width)
            .put("height", height)
            .put("fps", fps)
            .put("quality", quality)
            .toString()

    fun gesture(strokes: List<StrokePoint>): String {
        val strokesJson = JSONArray()
        strokes.forEach { stroke ->
            val pointsJson = JSONArray()
            stroke.points.forEach { p ->
                pointsJson.put(JSONArray().put(p.x).put(p.y))
            }
            strokesJson.put(
                JSONObject()
                    .put("start", stroke.startTimeMs)
                    .put("duration", stroke.durationMs)
                    .put("points", pointsJson)
            )
        }
        return JSONObject()
            .put(TYPE, INPUT_GESTURE)
            .put("strokes", strokesJson)
            .toString()
    }

    fun key(action: String): String =
        JSONObject().put(TYPE, INPUT_KEY).put("key", action).toString()

    fun text(value: String): String =
        JSONObject().put(TYPE, INPUT_TEXT).put("text", value.take(4096)).toString()

    fun sessionEnd(reason: String?): String =
        JSONObject().put(TYPE, SESSION_END).put("reason", reason.orEmpty()).toString()

    /** 解析被控端下发的手势；非法数据返回 null。 */
    fun parseGesture(json: JSONObject): List<StrokePoint>? {
        val arr = json.optJSONArray("strokes") ?: return null
        val result = ArrayList<StrokePoint>(arr.length())
        for (i in 0 until arr.length()) {
            val stroke = arr.optJSONObject(i) ?: continue
            val pointsArr = stroke.optJSONArray("points") ?: continue
            val points = ArrayList<NormalizedPoint>(pointsArr.length())
            for (j in 0 until pointsArr.length()) {
                val pair = pointsArr.optJSONArray(j) ?: continue
                if (pair.length() < 2) continue
                val x = pair.optDouble(0, Double.NaN)
                val y = pair.optDouble(1, Double.NaN)
                if (!x.isFinite() || !y.isFinite()) continue
                points.add(
                    NormalizedPoint(
                        x.coerceIn(0.0, 1.0).toFloat(),
                        y.coerceIn(0.0, 1.0).toFloat()
                    )
                )
            }
            if (points.isEmpty()) continue
            result.add(
                StrokePoint(
                    points = points,
                    startTimeMs = stroke.optLong("start", 0L).coerceIn(0L, 60000L),
                    durationMs = stroke.optLong("duration", 100L).coerceIn(1L, 60000L)
                )
            )
        }
        return result.takeIf { it.isNotEmpty() }?.take(10)
    }
}
