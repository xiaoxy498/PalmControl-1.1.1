package com.palmcontrol.util

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.view.accessibility.AccessibilityManager
import com.palmcontrol.service.RemoteAccessibilityService

data class Config(
    val serverUrl: String,
    val deviceName: String,
    val pin: String,
    val autoAccept: Boolean,
    val qualityIndex: Int,
    val fpsIndex: Int
)

object Prefs {
    private const val FILE = "palmcontrol_prefs"
    private const val KEY_SERVER = "server_url"
    private const val KEY_DEVICE = "device_name"
    private const val KEY_PIN = "pairing_pin"
    private const val KEY_AUTO = "auto_accept"
    private const val KEY_QUALITY = "quality_index"
    private const val KEY_FPS = "fps_index"
    private const val KEY_ALLOW_SHARE = "allow_share"
    private const val KEY_CURRENT_USER = "current_user"
    private const val KEY_AUTH_TOKEN = "auth_token"

    val FPS_VALUES = intArrayOf(10, 15, 20)
    val QUALITY_TARGET_WIDTHS = intArrayOf(480, 720, 1080)
    val QUALITY_JPEG = intArrayOf(45, 62, 78)

    const val DEFAULT_QUALITY = 1
    const val DEFAULT_FPS = 1

    /** 作者提供的公共中继，可直接使用；用户可在设置中改成自己的服务器。 */
    const val DEFAULT_SERVER = "ws://106.14.219.48:8080/ws"

    fun defaultDeviceName(): String =
        Build.MODEL?.takeIf { it.isNotBlank() } ?: "Android"

    fun load(context: Context): Config {
        val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return Config(
            serverUrl = prefs.getString(KEY_SERVER, DEFAULT_SERVER)
                ?.takeIf { it.isNotBlank() } ?: DEFAULT_SERVER,
            deviceName = prefs.getString(KEY_DEVICE, defaultDeviceName())
                ?.takeIf { it.isNotBlank() } ?: defaultDeviceName(),
            pin = prefs.getString(KEY_PIN, "").orEmpty(),
            autoAccept = prefs.getBoolean(KEY_AUTO, false),
            qualityIndex = prefs.getInt(KEY_QUALITY, DEFAULT_QUALITY).coerceIn(0, 2),
            fpsIndex = prefs.getInt(KEY_FPS, DEFAULT_FPS).coerceIn(0, 2)
        )
    }

    fun save(context: Context, config: Config) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_SERVER, config.serverUrl)
            .putString(KEY_DEVICE, config.deviceName)
            .putString(KEY_PIN, config.pin)
            .putBoolean(KEY_AUTO, config.autoAccept)
            .putInt(KEY_QUALITY, config.qualityIndex)
            .putInt(KEY_FPS, config.fpsIndex)
            .apply()
    }

    fun isShareAllowed(context: Context): Boolean =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_ALLOW_SHARE, false)

    fun setShareAllowed(context: Context, allowed: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ALLOW_SHARE, allowed)
            .apply()
    }

    fun currentUser(context: Context): String? =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_CURRENT_USER, null)
            ?.takeIf { it.isNotBlank() }

    fun setCurrentUser(context: Context, username: String?) {
        val editor = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_CURRENT_USER, username)
        if (username == null) editor.remove(KEY_AUTH_TOKEN)
        editor.apply()
    }

    fun authToken(context: Context): String? =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_AUTH_TOKEN, null)
            ?.takeIf { it.isNotBlank() }

    fun setAuthToken(context: Context, token: String?) {
        val editor = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
        if (token == null) editor.remove(KEY_AUTH_TOKEN) else editor.putString(KEY_AUTH_TOKEN, token)
        editor.apply()
    }

    fun isAccessibilityEnabled(context: Context): Boolean {
        val manager = context.getSystemService(AccessibilityManager::class.java) ?: return false
        val expected = ComponentName(context, RemoteAccessibilityService::class.java)
        return manager
            .getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { info ->
                val serviceInfo = info.resolveInfo?.serviceInfo ?: return@any false
                serviceInfo.packageName == expected.packageName &&
                    (serviceInfo.name == expected.className ||
                        serviceInfo.name == ".service.RemoteAccessibilityService")
            }
    }
}
