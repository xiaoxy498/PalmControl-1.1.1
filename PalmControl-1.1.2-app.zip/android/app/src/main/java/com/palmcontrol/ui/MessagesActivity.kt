package com.palmcontrol.ui

import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.card.MaterialCardView
import com.palmcontrol.R
import com.palmcontrol.databinding.ActivityMessagesBinding
import com.palmcontrol.util.AccountApi
import com.palmcontrol.util.Prefs
import com.palmcontrol.util.ServerUrl
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MessagesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMessagesBinding
    private var pollJob: Job? = null
    private var base: String? = null
    private var token: String? = null
    private var lastMessages: List<AccountApi.InboxMessage> = emptyList()
    private val timeFormat = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMessagesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        (binding.toolbar as? MaterialToolbar)?.setNavigationOnClickListener { finish() }

        base = ServerUrl.toHttpBase(Prefs.load(this).serverUrl)
        token = Prefs.authToken(this)
        if (base == null || token == null) {
            toast(getString(R.string.messages_login_required))
            finish()
            return
        }

        binding.tvEmpty.isVisible = true
        startPolling()
    }

    override fun onDestroy() {
        pollJob?.cancel()
        super.onDestroy()
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = lifecycleScope.launch {
            while (isActive) {
                loadMessages()
                delay(4000)
            }
        }
    }

    private suspend fun loadMessages() {
        val url = base ?: return
        val auth = token ?: return
        when (val inbox = AccountApi.inbox(url, auth)) {
            is AccountApi.Inbox.Success -> render(inbox.messages)
            is AccountApi.Inbox.Unauthorized -> {
                toast(getString(R.string.messages_session_expired))
                Prefs.setCurrentUser(this, null)
                finish()
            }
            is AccountApi.Inbox.Failure -> {
                if (lastMessages.isEmpty()) binding.tvEmpty.isVisible = true
            }
        }
    }

    private fun render(messages: List<AccountApi.InboxMessage>) {
        lastMessages = messages
        binding.tvEmpty.isVisible = messages.isEmpty()
        binding.llMessages.removeAllViews()
        messages.forEach { message ->
            binding.llMessages.addView(messageCard(message))
        }
    }

    private fun messageCard(message: AccountApi.InboxMessage): MaterialCardView {
        val card = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
            radius = dp(14).toFloat()
            setCardBackgroundColor(ContextCompat.getColor(this@MessagesActivity, R.color.surface_card))
            strokeWidth = 0
            isClickable = message.read
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }

        val title = TextView(this).apply {
            text = message.title.ifBlank { getString(R.string.messages_title) }
            setTextColor(ContextCompat.getColor(this@MessagesActivity, R.color.text_primary))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        val meta = TextView(this).apply {
            val stamp = if (message.createdAt > 0) {
                timeFormat.format(Date(message.createdAt))
            } else {
                ""
            }
            text = if (message.read) stamp else "$stamp · 未读"
            setTextColor(
                ContextCompat.getColor(
                    this@MessagesActivity,
                    if (message.read) R.color.text_secondary else R.color.warning_amber
                )
            )
            textSize = 11f
            setPadding(0, dp(4), 0, 0)
        }

        val body = TextView(this).apply {
            text = message.body
            setTextColor(ContextCompat.getColor(this@MessagesActivity, R.color.text_primary))
            textSize = 14f
            setPadding(0, dp(8), 0, 0)
            gravity = Gravity.START
        }

        content.addView(title)
        content.addView(meta)
        content.addView(body)
        card.addView(content)

        if (!message.read) {
            card.setOnClickListener { markRead(message) }
        }
        return card
    }

    private fun markRead(message: AccountApi.InboxMessage) {
        val url = base ?: return
        val auth = token ?: return
        lifecycleScope.launch {
            if (AccountApi.markRead(url, auth, message.id)) {
                render(lastMessages.map {
                    if (it.id == message.id) it.copy(read = true) else it
                })
            }
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
    }
}
