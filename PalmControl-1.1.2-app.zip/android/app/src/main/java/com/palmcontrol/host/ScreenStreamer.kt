package com.palmcontrol.host

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.ByteArrayOutputStream

/**
 * 采集屏幕并通过回调输出 JPEG 帧。
 *
 * 核心技术点：
 *  - VirtualDisplay 直接以目标分辨率创建，由系统做 GPU 缩放，省去逐帧 CPU 缩放；
 *  - ImageReader 读取 RGBA_8888，处理 rowStride 填充；
 *  - 按目标 FPS 节流，避免无意义编码；
 *  - 全程复用 Bitmap / ByteArrayOutputStream，减少 GC。
 */
class ScreenStreamer(
    private val context: Context,
    private val projection: MediaProjection,
    private val config: StreamConfig,
    private val callback: Callback
) {
    interface Callback {
        fun onVideoConfig(width: Int, height: Int, fps: Int, quality: Int)
        fun onFrame(jpeg: ByteArray)
        fun onStats(fps: Int, kbps: Int)
        fun onError(message: String)
    }

    private val thread = HandlerThread("palm-screen-capture").apply { start() }
    private val handler = Handler(thread.looper)

    @Volatile
    private var running = true

    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var paddedBitmap: Bitmap? = null
    private var croppedBitmap: Bitmap? = null
    private var paddedWidth = 0
    private var outputStream = ByteArrayOutputStream(512 * 1024)

    private var lastFrameAt = 0L
    private var statsSince = 0L
    private var frameCounter = 0
    private var bytesCounter = 0L
    private var errorReported = false

    private val frameIntervalMs = (1000L / config.fps.coerceAtLeast(1)).coerceAtLeast(1L)

    fun start() {
        handler.post { setup() }
    }

    private fun setup() {
        if (!running) return
        try {
            val display = displaySize()
            val output = StreamPresets.outputSize(display[0], display[1], config.targetWidth)
            val width = output[0]
            val height = output[1]

            val newReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            reader = newReader
            newReader.setOnImageAvailableListener({ onImageAvailable(it) }, handler)

            virtualDisplay = projection.createVirtualDisplay(
                "PalmControl",
                width,
                height,
                context.resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface,
                null,
                handler
            )

            statsSince = SystemClock.uptimeMillis()
            callback.onVideoConfig(width, height, config.fps, config.jpegQuality)
        } catch (t: Throwable) {
            reportError(t)
        }
    }

    private fun onImageAvailable(source: ImageReader) {
        if (!running) return
        val image = try {
            source.acquireLatestImage()
        } catch (t: Throwable) {
            null
        } ?: return

        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastFrameAt < frameIntervalMs) return

            val width = image.width
            val height = image.height
            val plane = image.planes.firstOrNull() ?: return
            if (plane.pixelStride != 4) return

            val rowStride = plane.rowStride
            val currentPaddedWidth = rowStride / plane.pixelStride
            if (currentPaddedWidth < width) return

            val padded = ensurePaddedBitmap(currentPaddedWidth, height) ?: return
            padded.copyPixelsFromBuffer(plane.buffer)

            val toEncode = if (currentPaddedWidth == width) {
                padded
            } else {
                ensureCroppedBitmap(width, height) ?: return
            }
            if (currentPaddedWidth != width) {
                val canvas = Canvas(toEncode)
                canvas.drawBitmap(
                    padded,
                    Rect(0, 0, width, height),
                    Rect(0, 0, width, height),
                    null
                )
            }

            lastFrameAt = now
            outputStream.reset()
            toEncode.compress(Bitmap.CompressFormat.JPEG, config.jpegQuality, outputStream)
            if (outputStream.size() == 0) return

            val jpeg = outputStream.toByteArray()
            frameCounter++
            bytesCounter += jpeg.size
            callback.onFrame(jpeg)
            reportStatsIfNeeded(now)
        } catch (t: Throwable) {
            reportError(t)
        } finally {
            image.close()
        }
    }

    private fun ensurePaddedBitmap(width: Int, height: Int): Bitmap? {
        val existing = paddedBitmap
        if (existing != null && paddedWidth == width && existing.height == height) return existing
        releaseBitmap(paddedBitmap)
        paddedWidth = width
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            .also { paddedBitmap = it }
    }

    private fun ensureCroppedBitmap(width: Int, height: Int): Bitmap? {
        val existing = croppedBitmap
        if (existing != null && existing.width == width && existing.height == height) return existing
        releaseBitmap(croppedBitmap)
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            .also { croppedBitmap = it }
    }

    private fun reportStatsIfNeeded(now: Long) {
        if (now - statsSince < 1000L) return
        val fps = frameCounter
        val kbps = (bytesCounter / 1024L).toInt()
        frameCounter = 0
        bytesCounter = 0
        statsSince = now
        callback.onStats(fps, kbps)
    }

    private fun reportError(t: Throwable) {
        if (errorReported) return
        errorReported = true
        callback.onError(t.message ?: "屏幕采集失败")
    }

    private fun displaySize(): IntArray {
        val wm = context.getSystemService(WindowManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            return intArrayOf(bounds.width(), bounds.height())
        }
        @Suppress("DEPRECATION")
        val metrics = DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
        return intArrayOf(metrics.widthPixels, metrics.heightPixels)
    }

    fun stop() {
        running = false
        handler.post { releaseResources() }
        runCatching { thread.quitSafely() }
        runCatching { thread.join(800) }
    }

    private fun releaseResources() {
        runCatching { reader?.setOnImageAvailableListener(null, null) }
        runCatching { reader?.close() }
        reader = null
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        releaseBitmap(paddedBitmap)
        paddedBitmap = null
        releaseBitmap(croppedBitmap)
        croppedBitmap = null
        outputStream.reset()
    }

    private fun releaseBitmap(bitmap: Bitmap?) {
        if (bitmap != null && !bitmap.isRecycled) {
            runCatching { bitmap.recycle() }
        }
    }
}
