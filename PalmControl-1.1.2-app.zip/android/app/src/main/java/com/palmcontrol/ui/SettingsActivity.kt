package com.palmcontrol.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.palmcontrol.R
import com.palmcontrol.databinding.ActivitySettingsBinding
import com.palmcontrol.host.StreamPresets
import com.palmcontrol.util.Prefs
import com.palmcontrol.util.ServerUrl

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val config = Prefs.load(this)
        binding.etServer.setText(config.serverUrl)
        binding.etDeviceName.setText(config.deviceName)
        binding.etPin.setText(config.pin)
        binding.switchAutoAccept.isChecked = config.autoAccept
        binding.spinnerQuality.setSelection(config.qualityIndex)
        binding.spinnerFps.setSelection(config.fpsIndex)
        binding.switchAllowShare.isChecked = Prefs.isShareAllowed(this)
        binding.btnLogout.isVisible = Prefs.currentUser(this) != null

        binding.btnBack.setOnClickListener { finish() }
        binding.btnSave.setOnClickListener { save() }
        binding.btnReset.setOnClickListener { resetToDefaults() }
        binding.switchAllowShare.setOnCheckedChangeListener { _, checked ->
            Prefs.setShareAllowed(this, checked)
        }
        binding.btnLogout.setOnClickListener { confirmLogout() }
    }

    private fun confirmLogout() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.profile_logout)
            .setMessage(R.string.logout_message)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.profile_logout) { _, _ ->
                Prefs.setCurrentUser(this, null)
                toast(R.string.logout_done)
                finish()
            }
            .show()
    }

    private fun save() {
        val rawServer = binding.etServer.text?.toString()?.trim().orEmpty()
        if (rawServer.isNotBlank() && !ServerUrl.isValid(rawServer)) {
            toast(R.string.invalid_server)
            return
        }
        val pin = binding.etPin.text?.toString()?.trim().orEmpty()
        if (pin.isNotEmpty() && !pin.matches(Regex("\\d{4,6}"))) {
            toast(R.string.invalid_pin)
            return
        }
        val deviceName = binding.etDeviceName.text?.toString()?.trim().orEmpty()
            .ifBlank { Prefs.defaultDeviceName() }

        val config = Prefs.load(this).copy(
            serverUrl = if (rawServer.isBlank()) Prefs.DEFAULT_SERVER
            else ServerUrl.normalize(rawServer).orEmpty(),
            deviceName = deviceName,
            pin = pin,
            autoAccept = binding.switchAutoAccept.isChecked,
            qualityIndex = binding.spinnerQuality.selectedItemPosition.coerceIn(0, 2),
            fpsIndex = binding.spinnerFps.selectedItemPosition.coerceIn(0, 2)
        )
        Prefs.save(this, config)
        toast(R.string.saved)
    }

    private fun resetToDefaults() {
        binding.etServer.setText(Prefs.DEFAULT_SERVER)
        binding.etDeviceName.setText(Prefs.defaultDeviceName())
        binding.etPin.setText("")
        binding.switchAutoAccept.isChecked = false
        binding.switchAllowShare.isChecked = false
        Prefs.setShareAllowed(this, false)
        binding.spinnerQuality.setSelection(Prefs.DEFAULT_QUALITY)
        binding.spinnerFps.setSelection(Prefs.DEFAULT_FPS)
        Prefs.save(
            this,
            Prefs.load(this).copy(
                serverUrl = Prefs.DEFAULT_SERVER,
                deviceName = Prefs.defaultDeviceName(),
                pin = "",
                autoAccept = false,
                qualityIndex = Prefs.DEFAULT_QUALITY,
                fpsIndex = Prefs.DEFAULT_FPS
            )
        )
        toast(R.string.saved)
    }

    private fun toast(res: Int) {
        Toast.makeText(this, res, Toast.LENGTH_SHORT).show()
    }
}
