package com.palmcontrol.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.palmcontrol.R
import com.palmcontrol.host.InputInjector
import com.palmcontrol.host.ScreenStreamer
import com.palmcontrol.host.StreamPresets
import com.palmcontrol.net.Messages
import com.palmcontrol.net.RelayClient
import com.palmcontrol.ui.HostActivity
import com.palmcontrol.util.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * 被控端核心服务：前台服务 + MediaProjection + 中继连接 + 输入注入。
 * 界面上只通过 Binder 读取 StateFlow，并调用 decidePending()/stopSharing()。
 */
class ScreenCaptureService : Service() {

    companion object {
        private const val CHANNEL_ID = "palm_screen_share"
        private const val NOTIFICATION_ID = 1201
        private const val JOIN_TIMEOUT_MS = 30_000L

        const val ACTION_START = "com.palmcontrol.action.START"
        const val ACTION_STOP = "com.palmcontrol.action.STOP"

        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        const val EXTRA_SERVER = "server"
        const val EXTRA_PIN = "pin"
        const val EXTRA_DEVICE_NAME = "device_name"
        const val EXTRA_AUTO_ACCEPT = "auto_accept"
        const val EXTRA_QUALITY = "quality"
        const val EXTRA_FPS = "fps"
    }

    sealed class State {
        data object Idle : State()
        data object Connecting : State()
        data class Waiting(val code: String) : State()
        data class PendingApproval(val controllerId: String, val controllerName: String) : State()
        data class Controlling(val peerName: String) : State()
        data class Failed(val message: String) : State()
    }

    data class Stats(val fps: Int, val kbps: Int)

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()

    private val _stats = MutableStateFlow(Stats(0, 0))
    val stats: StateFlow<Stats> = _stats.asStateFlow()

    val pairingCode: String? get() = code
    val isActive: Boolean get() = running

    private val binder = LocalBinder()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var relay: RelayClient? = null
    private var projection: MediaProjection? = null
    private var streamer: ScreenStreamer? = null

    private var serverUrl = ""
    private var pin = ""
    private var deviceName = ""
    private var autoAccept = false
    private var qualityIndex = Prefs.DEFAULT_QUALITY
    private var fpsIndex = Prefs.DEFAULT_FPS

    private var code: String? = null
    private var peerName: String? = null
    private var pendingId: String? = null
    private var pendingName: String? = null
    private var pendingJob: Job? = null

    private var running = false
    private var streaming = false
    private var foreground = false

    inner class LocalBinder : Binder() {
        fun getService(): ScreenCaptureService = this@ScreenCaptureService
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (running) return START_NOT_STICKY
                startForegroundCompat(getString(R.string.status_connecting))
                beginSession(intent)
            }
            ACTION_STOP -> stopSharing()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun beginSession(intent: Intent) {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = parcelableIntent(intent)
        if (data == null || resultCode == 0) {
            fail(getString(R.string.projection_denied))
            return
        }

        serverUrl = intent.getStringExtra(EXTRA_SERVER).orEmpty()
        pin = intent.getStringExtra(EXTRA_PIN).orEmpty()
        deviceName = intent.getStringExtra(EXTRA_DEVICE_NAME).orEmpty()
            .ifBlank { Prefs.defaultDeviceName() }
        autoAccept = intent.getBooleanExtra(EXTRA_AUTO_ACCEPT, false)
        qualityIndex = intent.getIntExtra(EXTRA_QUALITY, Prefs.DEFAULT_QUALITY)
        fpsIndex = intent.getIntExtra(EXTRA_FPS, Prefs.DEFAULT_FPS)

        if (serverUrl.isBlank()) {
            fail(getString(R.string.host_server_missing))
            return
        }

        val manager = getSystemService(MediaProjectionManager::class.java)
        val mediaProjection = manager.getMediaProjection(resultCode, data)
        if (mediaProjection == null) {
            fail(getString(R.string.projection_denied))
            return
        }

        projection = mediaProjection
        running = true
        _state.value = State.Connecting
        mediaProjection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (running) {
                    fail(getString(R.string.projection_ended))
                }
            }
        }, Handler(Looper.getMainLooper()))

        connectRelay()
    }

    private fun parcelableIntent(intent: Intent): Intent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
    }

    private fun connectRelay() {
        val client = RelayClient(serverUrl, object : RelayClient.Listener {
            override fun onOpen() {
                registerHost()
            }

            override fun onText(payload: String) {
                handleServerMessage(payload)
            }

            override fun onBinary(payload: ByteArray) = Unit

            override fun onClosed(reason: String) {
                if (running) fail(reason.ifBlank { getString(R.string.peer_left) })
            }

            override fun onFailure(reason: String) {
                if (running) fail(reason)
            }
        }, Prefs.authToken(this))
        relay = client
        client.connect()
    }

    private fun registerHost() {
        relay?.sendText(Messages.hostRegister(deviceName, pin))
    }

    private fun handleServerMessage(payload: String) {
        val json = runCatching { JSONObject(payload) }.getOrNull() ?: return
        when (json.optString(Messages.TYPE)) {
            Messages.HOST_REGISTERED -> {
                val newCode = json.optString("code")
                if (newCode.isBlank()) return
                code = newCode
                _state.value = State.Waiting(newCode)
                updateNotification(getString(R.string.host_notification_waiting, newCode))
            }

            Messages.JOIN_REQUEST -> {
                val id = json.optString("controllerId")
                if (id.isBlank()) return
                val name = json.optString("deviceName").ifBlank {
                    getString(R.string.host_unknown_device)
                }
                if (autoAccept) {
                    peerName = name
                    relay?.sendText(Messages.joinDecision(id, true, null))
                    updateNotification(getString(R.string.notification_pending))
                } else {
                    showPendingRequest(id, name)
                }
            }

            Messages.PAIRED -> {
                val name = json.optString("peerName")
                    .ifBlank { peerName ?: pendingName ?: getString(R.string.host_unknown_device) }
                pendingJob?.cancel()
                pendingId = null
                pendingName = null
                peerName = name
                _state.value = State.Controlling(name)
                updateNotification(getString(R.string.host_notification_controlling, name))
                startStreaming()
            }

            Messages.PEER_LEFT, Messages.SESSION_END -> {
                if (!running) return
                stopStreaming()
                peerName = null
                val currentCode = code
                _state.value = if (currentCode != null) {
                    State.Waiting(currentCode)
                } else {
                    State.Failed(getString(R.string.peer_left))
                }
                if (currentCode != null) {
                    updateNotification(getString(R.string.host_notification_waiting, currentCode))
                }
            }

            Messages.ERROR -> {
                val message = json.optString("message").ifBlank { "服务器错误" }
                fail(message)
            }

            Messages.INPUT_GESTURE -> {
                if (!streaming) return
                val strokes = Messages.parseGesture(json) ?: return
                InputInjector.gesture(strokes)
            }

            Messages.INPUT_KEY -> {
                if (streaming) InputInjector.key(json.optString("key"))
            }

            Messages.INPUT_TEXT -> {
                if (streaming) InputInjector.text(json.optString("text"))
            }
        }
    }

    private fun showPendingRequest(id: String, name: String) {
        pendingJob?.cancel()
        pendingId = id
        pendingName = name
        _state.value = State.PendingApproval(id, name)
        updateNotification(getString(R.string.notification_pending))
        pendingJob = scope.launch {
            delay(JOIN_TIMEOUT_MS)
            if (pendingId == id) {
                pendingId = null
                pendingName = null
                relay?.sendText(Messages.joinDecision(id, false, getString(R.string.join_timeout)))
                _state.value = code?.let { State.Waiting(it) } ?: State.Idle
                updateNotification(getString(R.string.join_timeout))
            }
        }
    }

    fun decidePending(allow: Boolean) {
        val id = pendingId ?: return
        val name = pendingName
        pendingJob?.cancel()
        pendingId = null
        pendingName = null
        relay?.sendText(
            Messages.joinDecision(id, allow, if (allow) null else getString(R.string.deny))
        )
        if (allow) {
            peerName = name
            val currentCode = code
            _state.value = if (currentCode != null) State.Waiting(currentCode) else State.Connecting
        } else {
            _state.value = code?.let { State.Waiting(it) } ?: State.Idle
        }
    }

    private fun startStreaming() {
        if (streaming) return
        val mediaProjection = projection ?: return
        val config = StreamPresets.create(qualityIndex, fpsIndex)
        val newStreamer = ScreenStreamer(
            context = this,
            projection = mediaProjection,
            config = config,
            callback = object : ScreenStreamer.Callback {
                override fun onVideoConfig(width: Int, height: Int, fps: Int, quality: Int) {
                    relay?.sendText(Messages.videoConfig(width, height, fps, quality))
                }

                override fun onFrame(jpeg: ByteArray) {
                    relay?.sendBinary(jpeg)
                }

                override fun onStats(fps: Int, kbps: Int) {
                    _stats.value = Stats(fps, kbps)
                }

                override fun onError(message: String) {
                    fail(message)
                }
            })
        streamer = newStreamer
        streaming = true
        newStreamer.start()
    }

    private fun stopStreaming() {
        streamer?.stop()
        streamer = null
        streaming = false
        _stats.value = Stats(0, 0)
    }

    private fun releaseProjection() {
        val current = projection
        projection = null
        runCatching { current?.stop() }
    }

    private fun fail(message: String) {
        if (!running) {
            _state.value = State.Failed(message)
            return
        }
        running = false
        pendingJob?.cancel()
        pendingId = null
        pendingName = null
        stopStreaming()
        relay?.close()
        relay = null
        releaseProjection()
        peerName = null
        _state.value = State.Failed(message)
        stopForegroundCompat()
        stopSelf()
    }

    fun stopSharing() {
        if (!running && _state.value is State.Idle) return
        running = false
        pendingJob?.cancel()
        stopStreaming()
        relay?.close()
        relay = null
        releaseProjection()
        code = null
        peerName = null
        pendingId = null
        pendingName = null
        _state.value = State.Idle
        stopForegroundCompat()
        stopSelf()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (streaming) {
            stopStreaming()
            startStreaming()
        }
    }

    override fun onDestroy() {
        running = false
        pendingJob?.cancel()
        scope.cancel()
        stopStreaming()
        relay?.close()
        relay = null
        releaseProjection()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.host_notification_channel),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.host_notification_title)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, HostActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.host_notification_title))
            .setContentText(text)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, getString(R.string.host_notification_stop), stopIntent)
            .build()
    }

    private fun startForegroundCompat(text: String) {
        val notification = buildNotification(text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        foreground = true
    }

    private fun updateNotification(text: String) {
        if (!foreground) return
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun stopForegroundCompat() {
        if (!foreground) return
        foreground = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
    }
}
