package com.palmcontrol.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** 服务端账号接口。账号以服务端为准，后台才能实时看到并封禁。 */
object AccountApi {

    sealed class Outcome {
        data class Success(
            val username: String,
            val email: String,
            val token: String,
            val banned: Boolean = false
        ) : Outcome()
        data object UserExists : Outcome()
        data object InvalidCredentials : Outcome()
        data class Failure(val reason: String) : Outcome()
    }

    data class InboxMessage(
        val id: String,
        val title: String,
        val body: String,
        val createdAt: Long,
        val read: Boolean
    )

    sealed class Inbox {
        data class Success(val messages: List<InboxMessage>, val unread: Int) : Inbox()
        data object Unauthorized : Inbox()
        data class Failure(val reason: String) : Inbox()
    }

    private val json = "application/json; charset=utf-8".toMediaType()
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun register(
        base: String,
        username: String,
        email: String,
        password: String,
        migrate: Boolean = false
    ): Outcome = requestAuth("$base/api/auth/register") {
        JSONObject()
            .put("username", username)
            .put("email", email)
            .put("password", password)
            .put("migrate", migrate)
    }

    suspend fun login(base: String, username: String, password: String): Outcome =
        requestAuth("$base/api/auth/login") {
            JSONObject().put("username", username).put("password", password)
        }

    /** true 表示服务端确认账号仍可用；封禁账号返回 banned=true，但仍保持登录。 */
    suspend fun checkSession(base: String, token: String): Outcome = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$base/api/auth/me")
                .header("authorization", "Bearer $token")
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                val body = JSONObject(response.body?.string().orEmpty())
                if (response.isSuccessful) {
                    val user = body.optJSONObject("user")
                    return@withContext Outcome.Success(
                        user?.optString("username").orEmpty(),
                        user?.optString("email").orEmpty(),
                        token,
                        user?.optBoolean("banned") == true
                    )
                }
                Outcome.InvalidCredentials
            }
        } catch (e: Exception) {
            Outcome.Failure(e.message ?: "network_error")
        }
    }

    suspend fun inbox(base: String, token: String): Inbox = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$base/api/messages")
                .header("authorization", "Bearer $token")
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                val body = JSONObject(response.body?.string().orEmpty())
                when {
                    response.isSuccessful -> {
                        val array = body.optJSONArray("messages")
                        val list = ArrayList<InboxMessage>()
                        for (i in 0 until (array?.length() ?: 0)) {
                            val item = array?.optJSONObject(i) ?: continue
                            list.add(
                                InboxMessage(
                                    id = item.optString("id"),
                                    title = item.optString("title"),
                                    body = item.optString("body"),
                                    createdAt = item.optLong("createdAt"),
                                    read = item.optBoolean("read")
                                )
                            )
                        }
                        Inbox.Success(list.asReversed(), body.optInt("unread"))
                    }
                    response.code == 401 -> Inbox.Unauthorized
                    else -> Inbox.Failure("http_${response.code}")
                }
            }
        } catch (e: Exception) {
            Inbox.Failure(e.message ?: "network_error")
        }
    }

    suspend fun markRead(base: String, token: String, messageId: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val request = Request.Builder()
                    .url("$base/api/messages/$messageId/read")
                    .header("authorization", "Bearer $token")
                    .post(JSONObject().toString().toRequestBody(json))
                    .build()
                client.newCall(request).execute().use { it.isSuccessful }
            } catch (e: Exception) {
                false
            }
        }

    private suspend fun requestAuth(
        url: String,
        payload: () -> JSONObject
    ): Outcome = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(url)
                .post(payload().toString().toRequestBody(json))
                .build()
            client.newCall(request).execute().use { response ->
                val body = JSONObject(response.body?.string().orEmpty())
                if (response.isSuccessful) {
                    val user = body.optJSONObject("user")
                    return@withContext Outcome.Success(
                        user?.optString("username").orEmpty(),
                        user?.optString("email").orEmpty(),
                        body.optString("token"),
                        user?.optBoolean("banned") == true
                    )
                }
                when (val error = body.optString("error")) {
                    "user_exists" -> Outcome.UserExists
                    "invalid_credentials" -> Outcome.InvalidCredentials
                    else -> Outcome.Failure(error.ifBlank { "http_${response.code}" })
                }
            }
        } catch (e: Exception) {
            Outcome.Failure(e.message ?: "network_error")
        }
    }
}
