package com.palmcontrol.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import android.webkit.MimeTypeMap
import org.json.JSONObject
import java.io.ByteArrayOutputStream

data class ChatAttachment(
    val name: String,
    val mime: String,
    val data: String
) {
    val isImage: Boolean get() = mime.startsWith("image/")

    fun bytes(): ByteArray = Base64.decode(data, Base64.DEFAULT)

    fun toJson(): JSONObject = JSONObject()
        .put("name", name)
        .put("mime", mime)
        .put("data", data)

    companion object {
        const val MAX_BYTES = 3 * 1024 * 1024

        fun fromJson(json: JSONObject?): ChatAttachment? {
            if (json == null) return null
            val data = json.optString("data")
            if (data.isBlank()) return null
            return ChatAttachment(
                name = json.optString("name").ifBlank { "附件" },
                mime = json.optString("mime").ifBlank { "application/octet-stream" },
                data = data
            )
        }

        fun fromUri(context: Context, uri: Uri): ChatAttachment {
            val resolver = context.contentResolver
            var name = "附件"
            resolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) {
                        name = cursor.getString(index)?.takeIf { it.isNotBlank() } ?: name
                    }
                }
            }

            var mime = resolver.getType(uri)
            if (mime.isNullOrBlank()) {
                val extension = name.substringAfterLast('.', "").lowercase()
                mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
            }
            if (mime.isNullOrBlank()) mime = "application/octet-stream"

            val output = ByteArrayOutputStream()
            resolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(8192)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    output.write(buffer, 0, count)
                    if (output.size() > MAX_BYTES) {
                        throw IllegalArgumentException("文件不能超过 3 MB")
                    }
                }
            } ?: throw IllegalArgumentException("无法读取所选文件")

            val bytes = output.toByteArray()
            if (bytes.isEmpty()) throw IllegalArgumentException("不能上传空文件")
            return ChatAttachment(name, mime, Base64.encodeToString(bytes, Base64.NO_WRAP))
        }
    }
}
