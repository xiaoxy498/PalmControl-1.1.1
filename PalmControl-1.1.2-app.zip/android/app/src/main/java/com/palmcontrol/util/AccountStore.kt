package com.palmcontrol.util

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * 本地账号存储：只保存在本机 SharedPreferences。
 * 密码使用 PBKDF2-HMAC-SHA256 加盐哈希，不保存明文。
 */
object AccountStore {

    sealed class Result {
        data object Success : Result()
        data object UserExists : Result()
        data object InvalidCredentials : Result()
    }

    private const val FILE = "palmcontrol_accounts"
    private const val ITERATIONS = 120_000
    private const val KEY_LENGTH = 256
    private const val SALT_BYTES = 16

    fun register(context: Context, username: String, password: String): Result {
        val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val key = keyOf(username)
        if (prefs.contains(key)) return Result.UserExists

        val salt = ByteArray(SALT_BYTES).also { SecureRandom().nextBytes(it) }
        val encoded = Base64.encodeToString(salt, Base64.NO_WRAP) + ":" +
            Base64.encodeToString(hash(password, salt), Base64.NO_WRAP)
        prefs.edit().putString(key, encoded).apply()
        return Result.Success
    }

    fun login(context: Context, username: String, password: String): Result {
        val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val stored = prefs.getString(keyOf(username), null) ?: return Result.InvalidCredentials
        val parts = stored.split(":")
        if (parts.size != 2) return Result.InvalidCredentials

        val salt = runCatching { Base64.decode(parts[0], Base64.NO_WRAP) }.getOrNull()
            ?: return Result.InvalidCredentials
        val actual = Base64.encodeToString(hash(password, salt), Base64.NO_WRAP)
        return if (constantTimeEquals(parts[1], actual)) Result.Success else Result.InvalidCredentials
    }

    private fun keyOf(username: String): String = "u_" + username.lowercase()

    private fun hash(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec)
                .encoded
        } finally {
            spec.clearPassword()
        }
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].code xor b[i].code)
        return diff == 0
    }
}
