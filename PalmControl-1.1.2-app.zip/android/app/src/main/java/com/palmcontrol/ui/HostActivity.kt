package com.palmcontrol.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.palmcontrol.R
import com.palmcontrol.databinding.ActivityHostBinding
import com.palmcontrol.service.ScreenCaptureService
import com.palmcontrol.util.Prefs
import com.palmcontrol.util.ServerUrl
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class HostActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHostBinding
    private var service: ScreenCaptureService? = null
    private var bound = false
    private var stateJob: Job? = null
    private var currentState: ScreenCaptureService.State = ScreenCaptureService.State.Idle
    private var joinDialog: AlertDialog? = null
    private var failedMessageShown: String? = null

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            startSharing(result.resultCode, data)
        } else {
            toast(getString(R.string.projection_denied))
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        launchProjectionPermission()
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val local = binder as? ScreenCaptureService.LocalBinder ?: return
            service = local.getService()
            bound = true
            observeService()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            bound = false
            stateJob?.cancel()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHostBinding.inflate(layoutInflater)
        setContentView(binding.root)

        configureFromPrefs()
        binding.btnBack.setOnClickListener { finish() }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.btnCopy.setOnClickListener { copyCode() }
        binding.btnShare.setOnClickListener { onShareClicked() }
        binding.rowAccessibility.setOnClickListener { openAccessibilitySettings() }
    }

    override fun onStart() {
        super.onStart()
        bindService(
            Intent(this, ScreenCaptureService::class.java),
            connection,
            Context.BIND_AUTO_CREATE
        )
    }

    override fun onResume() {
        super.onResume()
        refreshAccessibilityLabel()
        val config = Prefs.load(this)
        binding.tvPinState.text = if (config.pin.isBlank()) {
            getString(R.string.host_pin_none)
        } else {
            getString(R.string.host_pin_set, config.pin)
        }
        if (currentState is ScreenCaptureService.State.Idle) {
            binding.switchAutoAccept.isChecked = config.autoAccept
            binding.spinnerQuality.setSelection(config.qualityIndex)
            binding.spinnerFps.setSelection(config.fpsIndex)
        }
    }

    override fun onStop() {
        stateJob?.cancel()
        stateJob = null
        dismissJoinDialog()
        if (bound) {
            unbindService(connection)
            bound = false
        }
        service = null
        super.onStop()
    }

    private fun configureFromPrefs() {
        val config = Prefs.load(this)
        binding.spinnerQuality.setSelection(config.qualityIndex)
        binding.spinnerFps.setSelection(config.fpsIndex)
        binding.switchAutoAccept.isChecked = config.autoAccept
        binding.tvPinState.text = if (config.pin.isBlank()) {
            getString(R.string.host_pin_none)
        } else {
            getString(R.string.host_pin_set, config.pin)
        }
        render(ScreenCaptureService.State.Idle)
    }

    private fun observeService() {
        val svc = service ?: return
        stateJob?.cancel()
        stateJob = lifecycleScope.launch {
            svc.state.collect { render(it) }
        }
    }

    private fun render(state: ScreenCaptureService.State) {
        currentState = state
        val code = service?.pairingCode
        binding.tvCode.text = code ?: getString(R.string.host_code_placeholder)
        binding.btnCopy.isEnabled = code != null
        binding.cardCode.isVisible = code != null

        val statusText = when (state) {
            is ScreenCaptureService.State.Idle -> getString(R.string.status_idle)
            is ScreenCaptureService.State.Connecting -> getString(R.string.status_connecting)
            is ScreenCaptureService.State.Waiting -> getString(R.string.status_waiting)
            is ScreenCaptureService.State.PendingApproval -> getString(R.string.status_pending)
            is ScreenCaptureService.State.Controlling -> getString(R.string.status_controlling)
            is ScreenCaptureService.State.Failed -> state.message
        }
        binding.tvStatus.text = statusText
        binding.tvStatus.setTextColor(
            ContextCompat.getColor(
                this,
                when (state) {
                    is ScreenCaptureService.State.Failed -> R.color.danger_red
                    is ScreenCaptureService.State.Controlling -> R.color.success_green
                    else -> R.color.text_primary
                }
            )
        )

        binding.tvPeer.text = when (state) {
            is ScreenCaptureService.State.Controlling ->
                getString(R.string.host_peer, state.peerName)
            else -> getString(R.string.host_peer_none)
        }

        val connecting = state is ScreenCaptureService.State.Connecting
        binding.progress.isVisible = connecting
        binding.btnShare.isEnabled = service != null
        binding.btnShare.text = if (state is ScreenCaptureService.State.Idle ||
            state is ScreenCaptureService.State.Failed
        ) {
            getString(R.string.host_start)
        } else {
            getString(R.string.host_stop)
        }

        val busy = state !is ScreenCaptureService.State.Idle &&
            state !is ScreenCaptureService.State.Failed
        binding.spinnerQuality.isEnabled = !busy
        binding.spinnerFps.isEnabled = !busy
        binding.switchAutoAccept.isEnabled = !busy

        when (state) {
            is ScreenCaptureService.State.PendingApproval -> showJoinDialog(state)
            else -> dismissJoinDialog()
        }

        if (state is ScreenCaptureService.State.Failed && failedMessageShown != state.message) {
            failedMessageShown = state.message
            toast(state.message)
        }
        if (state is ScreenCaptureService.State.Idle) {
            failedMessageShown = null
        }
    }

    private fun onShareClicked() {
        val state = currentState
        if (state !is ScreenCaptureService.State.Idle &&
            state !is ScreenCaptureService.State.Failed
        ) {
            service?.stopSharing()
            return
        }

        val config = Prefs.load(this)
        val updated = config.copy(
            autoAccept = binding.switchAutoAccept.isChecked,
            qualityIndex = binding.spinnerQuality.selectedItemPosition.coerceIn(0, 2),
            fpsIndex = binding.spinnerFps.selectedItemPosition.coerceIn(0, 2)
        )
        Prefs.save(this, updated)

        val normalized = ServerUrl.normalize(updated.serverUrl)
        if (normalized == null) {
            toast(getString(R.string.host_server_missing))
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        if (!Prefs.isAccessibilityEnabled(this)) {
            toast(getString(R.string.accessibility_not_ready))
        }
        requestNotificationThenProjection()
    }

    private fun requestNotificationThenProjection() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchProjectionPermission()
        }
    }

    private fun launchProjectionPermission() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun startSharing(resultCode: Int, data: Intent) {
        val config = Prefs.load(this)
        val server = ServerUrl.normalize(config.serverUrl)
        if (server == null) {
            toast(getString(R.string.host_server_missing))
            return
        }
        val intent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_START
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_DATA, data)
            putExtra(ScreenCaptureService.EXTRA_SERVER, server)
            putExtra(ScreenCaptureService.EXTRA_PIN, config.pin)
            putExtra(ScreenCaptureService.EXTRA_DEVICE_NAME, config.deviceName)
            putExtra(ScreenCaptureService.EXTRA_AUTO_ACCEPT, config.autoAccept)
            putExtra(ScreenCaptureService.EXTRA_QUALITY, config.qualityIndex)
            putExtra(ScreenCaptureService.EXTRA_FPS, config.fpsIndex)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun showJoinDialog(state: ScreenCaptureService.State.PendingApproval) {
        if (joinDialog?.isShowing == true) return
        joinDialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.join_dialog_title)
            .setMessage(getString(R.string.join_dialog_message, state.controllerName))
            .setCancelable(false)
            .setPositiveButton(R.string.allow) { _, _ ->
                service?.decidePending(true)
            }
            .setNegativeButton(R.string.deny) { _, _ ->
                service?.decidePending(false)
            }
            .show()
    }

    private fun dismissJoinDialog() {
        joinDialog?.dismiss()
        joinDialog = null
    }

    private fun copyCode() {
        val code = service?.pairingCode ?: return
        val clipboard = getSystemService(ClipboardManager::class.java) ?: return
        clipboard.setPrimaryClip(ClipData.newPlainText("PalmControl code", code))
        toast(getString(R.string.host_copied))
    }

    private fun refreshAccessibilityLabel() {
        val enabled = Prefs.isAccessibilityEnabled(this)
        binding.tvAccessibilityState.text =
            getString(if (enabled) R.string.accessibility_on else R.string.accessibility_off)
        binding.tvAccessibilityState.setTextColor(
            ContextCompat.getColor(
                this,
                if (enabled) R.color.success_green else R.color.warning_amber
            )
        )
    }

    private fun openAccessibilitySettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }.onFailure {
            toast(getString(R.string.accessibility_off))
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun toast(message: Int) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
