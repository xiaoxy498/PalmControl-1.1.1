package com.palmcontrol.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.isVisible
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.palmcontrol.R
import com.palmcontrol.databinding.ActivityControllerBinding
import com.palmcontrol.databinding.DialogTextInputBinding
import com.palmcontrol.net.Messages
import com.palmcontrol.net.RelayClient
import com.palmcontrol.util.Prefs
import com.palmcontrol.util.ServerUrl
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

class ControllerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CODE = "extra_code"
        const val EXTRA_PIN = "extra_pin"
        const val EXTRA_AUTO_CONNECT = "extra_auto_connect"
    }

    private lateinit var binding: ActivityControllerBinding
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var paired = false

    private var relay: RelayClient? = null
    private var statsRunnable: Runnable? = null

    private val frameCounter = AtomicInteger(0)
    private val byteCounter = AtomicLong(0L)

    @Volatile
    private var currentResolution: Pair<Int, Int>? = null
    private var emptyHidden = false
    private var lastCode = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityControllerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val config = Prefs.load(this)
        val extraCode = intent.getStringExtra(EXTRA_CODE).orEmpty()
        val extraPin = intent.getStringExtra(EXTRA_PIN).orEmpty()
        binding.etServer.setText(config.serverUrl)
        binding.etCode.setText(extraCode.ifBlank { lastCode })
        binding.etPin.setText(extraPin)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.btnConnect.setOnClickListener {
            if (relay != null) disconnect() else connect()
        }
        binding.btnDisconnect.setOnClickListener { disconnect() }
        binding.btnMenu.setOnClickListener { toggleToolbar() }

        binding.btnKeyBack.setOnClickListener { sendKey("back") }
        binding.btnKeyHome.setOnClickListener { sendKey("home") }
        binding.btnKeyRecents.setOnClickListener { sendKey("recents") }
        binding.btnKeyNotifications.setOnClickListener { sendKey("notifications") }
        binding.btnKeyKeyboard.setOnClickListener { showTextDialog() }

        binding.remoteView.onGesture = { strokes ->
            if (paired) relay?.sendText(Messages.gesture(strokes))
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (paired) {
                    confirmDisconnect()
                } else {
                    relay?.close()
                    relay = null
                    finish()
                }
            }
        })

        if (savedInstanceState == null &&
            intent.getBooleanExtra(EXTRA_AUTO_CONNECT, false) &&
            extraCode.isNotBlank()
        ) {
            connect()
        }
    }

    private fun connect() {
        val code = binding.etCode.text?.toString()?.trim().orEmpty()
        if (!code.matches(Regex("\\d{6}"))) {
            showConnectError(getString(R.string.invalid_input))
            return
        }
        val server = ServerUrl.normalize(binding.etServer.text?.toString().orEmpty())
        if (server == null) {
            showConnectError(getString(R.string.invalid_input))
            return
        }
        val pin = binding.etPin.text?.toString()?.trim().orEmpty()

        lastCode = code
        val config = Prefs.load(this)
        Prefs.save(this, config.copy(serverUrl = server))

        binding.tvConnectError.isVisible = false
        binding.tvConnectStatus.isVisible = true
        binding.tvConnectStatus.text = getString(R.string.connecting)
        binding.progressConnect.isVisible = true
        binding.btnConnect.isEnabled = false
        paired = false
        emptyHidden = false

        relay?.close()
        val client = RelayClient(server, object : RelayClient.Listener {
            override fun onOpen() {
                postUi {
                    binding.tvConnectStatus.text = getString(R.string.waiting_approval)
                }
                relay?.sendText(Messages.controllerJoin(code, pin, config.deviceName))
            }

            override fun onText(payload: String) {
                handleServerMessage(payload)
            }

            override fun onBinary(payload: ByteArray) {
                if (!paired) return
                binding.remoteView.submitFrame(payload)
                frameCounter.incrementAndGet()
                byteCounter.addAndGet(payload.size.toLong())
                if (!emptyHidden) {
                    emptyHidden = true
                    postUi { binding.tvEmpty.isVisible = false }
                }
            }

            override fun onClosed(reason: String) {
                if (paired) {
                    endSession(getString(R.string.peer_left))
                } else {
                    showConnectError(getString(R.string.connect_failed, reason))
                }
            }

            override fun onFailure(reason: String) {
                if (paired) {
                    endSession(getString(R.string.connect_failed, reason))
                } else {
                    showConnectError(getString(R.string.connect_failed, reason))
                }
            }
        }, Prefs.authToken(this))
        relay = client
        client.connect()
    }

    private fun handleServerMessage(payload: String) {
        val json = runCatching { JSONObject(payload) }.getOrNull() ?: return
        when (json.optString(Messages.TYPE)) {
            Messages.JOIN_PENDING -> postUi {
                binding.tvConnectStatus.text = getString(R.string.waiting_approval)
            }

            Messages.PAIRED -> postUi { onPaired() }

            Messages.PEER_LEFT -> endSession(getString(R.string.peer_left))

            Messages.SESSION_END -> endSession(getString(R.string.session_closed))

            Messages.ERROR -> {
                val message = json.optString("message").ifBlank { "Server error" }
                endSession(getString(R.string.connect_failed, message))
            }

            Messages.VIDEO_CONFIG -> {
                val width = json.optInt("width")
                val height = json.optInt("height")
                if (width > 0 && height > 0) {
                    currentResolution = width to height
                }
            }
        }
    }

    private fun onPaired() {
        paired = true
        binding.connectPanel.isVisible = false
        binding.remotePanel.isVisible = true
        binding.tvEmpty.isVisible = true
        binding.progressConnect.isVisible = false
        binding.tvConnectStatus.isVisible = false
        binding.tvConnectError.isVisible = false
        binding.toolbarScroll.isVisible = true
        binding.btnMenu.text = getString(R.string.hide_menu)
        binding.btnConnect.isEnabled = true
        binding.btnConnect.text = getString(R.string.disconnect)
        emptyHidden = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()
        startStats()
    }

    private fun disconnect() {
        val wasPaired = paired
        if (wasPaired) relay?.sendText(Messages.sessionEnd("user"))
        relay?.close()
        relay = null
        paired = false
        stopStats()
        endSession(getString(if (wasPaired) R.string.session_closed else R.string.disconnect))
    }

    private fun endSession(message: String) {
        postUi {
            relay?.close()
            relay = null
            paired = false
            stopStats()
            binding.remoteView.clearFrame()
            binding.remotePanel.isVisible = false
            binding.connectPanel.isVisible = true
            binding.toolbarScroll.isVisible = false
            binding.tvEmpty.isVisible = true
            binding.progressConnect.isVisible = false
            binding.btnConnect.isEnabled = true
            binding.btnConnect.text = getString(R.string.connect)
            binding.tvConnectError.isVisible = false
            binding.tvConnectStatus.isVisible = true
            binding.tvConnectStatus.text = message
            binding.btnMenu.text = getString(R.string.menu)
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            exitImmersive()
            currentResolution = null
        }
    }

    private fun showConnectError(message: String) {
        postUi {
            relay?.close()
            relay = null
            paired = false
            stopStats()
            binding.progressConnect.isVisible = false
            binding.btnConnect.isEnabled = true
            binding.btnConnect.text = getString(R.string.connect)
            binding.tvConnectStatus.isVisible = false
            binding.tvConnectError.isVisible = true
            binding.tvConnectError.text = message
        }
    }

    private fun sendKey(action: String) {
        if (paired) relay?.sendText(Messages.key(action))
    }

    private fun toggleToolbar() {
        val show = !binding.toolbarScroll.isVisible
        binding.toolbarScroll.isVisible = show
        binding.btnMenu.text = getString(if (show) R.string.hide_menu else R.string.menu)
    }

    private fun showTextDialog() {
        if (!paired) return
        val dialogBinding = DialogTextInputBinding.inflate(layoutInflater)
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.send_text)
            .setView(dialogBinding.root)
            .create()
        dialogBinding.btnCancel.setOnClickListener { dialog.dismiss() }
        dialogBinding.btnSend.setOnClickListener {
            val text = dialogBinding.etText.text?.toString().orEmpty()
            if (text.isNotEmpty()) relay?.sendText(Messages.text(text))
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun confirmDisconnect() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.disconnect)
            .setMessage(R.string.session_closed)
            .setPositiveButton(R.string.disconnect) { _, _ -> disconnect() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun startStats() {
        stopStats()
        statsRunnable = object : Runnable {
            override fun run() {
                val frames = frameCounter.getAndSet(0)
                val bytes = byteCounter.getAndSet(0L)
                val kbps = (bytes / 1024L).toInt()
                val resolution = currentResolution
                val stats = buildString {
                    append(getString(R.string.stats_format, frames, kbps))
                    if (resolution != null) {
                        append(" · ")
                        append(
                            getString(
                                R.string.resolution_format,
                                resolution.first,
                                resolution.second
                            )
                        )
                    }
                }
                binding.tvRemoteStats.text = stats
                statsRunnable?.let { mainHandler.postDelayed(it, 1000L) }
            }
        }
        statsRunnable?.let { mainHandler.postDelayed(it, 1000L) }
    }

    private fun stopStats() {
        statsRunnable?.let { mainHandler.removeCallbacks(it) }
        statsRunnable = null
        frameCounter.set(0)
        byteCounter.set(0L)
    }

    private fun enterImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, binding.root).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun exitImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, binding.root)
            .show(WindowInsetsCompat.Type.systemBars())
    }

    private fun postUi(action: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) action() else mainHandler.post(action)
    }

    override fun onDestroy() {
        stopStats()
        relay?.close()
        relay = null
        super.onDestroy()
    }
}
