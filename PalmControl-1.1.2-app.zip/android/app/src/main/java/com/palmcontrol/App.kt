package com.palmcontrol

import android.app.Application

class App : Application()
