package com.palmcontrol.controller

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.SparseArray
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import com.palmcontrol.net.NormalizedPoint
import com.palmcontrol.net.StrokePoint
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/**
 * 远程画面控件：
 *  - 后台解码 JPEG，主线程绘制，解码跟不上时丢帧；
 *  - 触点坐标映射到画面归一化坐标；
 *  - 识别单击 / 长按 / 滑动 / 双指手势，交给 [onGesture] 发送。
 */
class RemoteView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var onGesture: ((List<StrokePoint>) -> Unit)? = null

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
    private val decoder = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "palm-frame-decoder").apply { isDaemon = true }
    }
    private val mainHandler = Handler(Looper.getMainLooper())
    private val decoding = AtomicBoolean(false)
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    private var frame: Bitmap? = null

    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var lastSampleTime = 0L
    private var moved = false
    private var multiTouch = false
    private var multiHandled = false
    private val points = ArrayList<Pair<Float, Float>>()
    private val pointerStarts = SparseArray<PointF>()

    init {
        setBackgroundColor(Color.BLACK)
        isClickable = true
        isFocusable = true
    }

    fun submitFrame(jpeg: ByteArray) {
        if (!decoding.compareAndSet(false, true)) return
        decoder.execute {
            val bitmap = try {
                BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size)
            } catch (t: Throwable) {
                null
            }
            mainHandler.post {
                decoding.set(false)
                if (bitmap != null) {
                    val old = frame
                    frame = bitmap
                    if (old != null && !old.isRecycled) old.recycle()
                    invalidate()
                }
            }
        }
    }

    fun clearFrame() {
        mainHandler.post {
            val old = frame
            frame = null
            if (old != null && !old.isRecycled) old.recycle()
            invalidate()
        }
    }

    override fun onDetachedFromWindow() {
        decoder.shutdownNow()
        val old = frame
        frame = null
        if (old != null && !old.isRecycled) old.recycle()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bitmap = frame ?: return
        val rect = contentRect(bitmap) ?: return
        canvas.drawBitmap(bitmap, null, rect, paint)
    }

    private fun contentRect(bitmap: Bitmap): RectF? {
        if (width <= 0 || height <= 0 || bitmap.width <= 0 || bitmap.height <= 0) return null
        val scale = min(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        val drawWidth = bitmap.width * scale
        val drawHeight = bitmap.height * scale
        val left = (width - drawWidth) / 2f
        val top = (height - drawHeight) / 2f
        return RectF(left, top, left + drawWidth, top + drawHeight)
    }

    private fun toNormalized(x: Float, y: Float): NormalizedPoint? {
        val bitmap = frame ?: return null
        val rect = contentRect(bitmap) ?: return null
        if (x < rect.left || x > rect.right || y < rect.top || y > rect.bottom) return null
        return NormalizedPoint(
            ((x - rect.left) / rect.width()).coerceIn(0f, 1f),
            ((y - rect.top) / rect.height()).coerceIn(0f, 1f)
        )
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = event.x
                downY = event.y
                downTime = event.eventTime
                lastSampleTime = downTime
                moved = false
                multiTouch = false
                multiHandled = false
                points.clear()
                pointerStarts.clear()
                points.add(event.x to event.y)
                pointerStarts.put(event.getPointerId(0), PointF(event.x, event.y))
                return true
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                multiTouch = true
                val index = event.actionIndex
                pointerStarts.put(
                    event.getPointerId(index),
                    PointF(event.getX(index), event.getY(index))
                )
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2) {
                    multiTouch = true
                    return true
                }
                val x = event.x
                val y = event.y
                if (abs(x - downX) > touchSlop || abs(y - downY) > touchSlop) moved = true
                if (event.eventTime - lastSampleTime >= 16L) {
                    points.add(x to y)
                    lastSampleTime = event.eventTime
                }
                return true
            }

            MotionEvent.ACTION_POINTER_UP -> {
                if (multiTouch && !multiHandled) {
                    emitMultiTouchGesture(event)
                    multiHandled = true
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                if (multiTouch) {
                    resetGesture()
                    return true
                }
                val elapsed = event.eventTime - downTime
                val distance = hypot(event.x - downX, event.y - downY)
                when {
                    !moved && distance <= touchSlop && elapsed < 300L -> {
                        emitSinglePoint(event.x, event.y, 80L)
                    }
                    distance <= touchSlop -> {
                        emitSinglePoint(event.x, event.y, 650L)
                    }
                    else -> {
                        points.add(event.x to event.y)
                        emitSwipe(event.eventTime)
                    }
                }
                resetGesture()
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                resetGesture()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun emitSinglePoint(x: Float, y: Float, durationMs: Long) {
        val point = toNormalized(x, y) ?: return
        onGesture?.invoke(
            listOf(StrokePoint(listOf(point), startTimeMs = 0L, durationMs = durationMs))
        )
    }

    private fun emitSwipe(upTime: Long) {
        val normalized = ArrayList<NormalizedPoint>(points.size)
        points.forEach { (x, y) ->
            toNormalized(x, y)?.let { normalized.add(it) }
        }
        if (normalized.isEmpty()) return
        if (normalized.size == 1) {
            onGesture?.invoke(
                listOf(StrokePoint(normalized, 0L, 80L))
            )
            return
        }
        val duration = (upTime - downTime).coerceIn(120L, 5000L)
        onGesture?.invoke(listOf(StrokePoint(normalized, 0L, duration)))
    }

    private fun emitMultiTouchGesture(event: MotionEvent) {
        val elapsed = (event.eventTime - downTime).coerceIn(100L, 3000L)
        val starts = ArrayList<PointF>(2)
        val ends = ArrayList<PointF>(2)
        for (i in 0 until event.pointerCount) {
            val id = event.getPointerId(i)
            val start = pointerStarts.get(id) ?: continue
            starts.add(start)
            ends.add(PointF(event.getX(i), event.getY(i)))
            if (starts.size == 2) break
        }
        if (starts.size < 2) return

        val strokes = ArrayList<StrokePoint>(2)
        for (i in 0 until 2) {
            val start = toNormalized(starts[i].x, starts[i].y)
            val end = toNormalized(ends[i].x, ends[i].y)
            if (start == null || end == null) return
            strokes.add(
                StrokePoint(
                    points = listOf(start, end),
                    startTimeMs = 0L,
                    durationMs = elapsed
                )
            )
        }
        onGesture?.invoke(strokes)
    }

    private fun resetGesture() {
        points.clear()
        pointerStarts.clear()
        moved = false
        multiTouch = false
        multiHandled = false
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
