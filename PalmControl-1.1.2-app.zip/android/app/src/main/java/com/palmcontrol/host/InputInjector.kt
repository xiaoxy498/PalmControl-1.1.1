package com.palmcontrol.host

import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Path
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import com.palmcontrol.net.StrokePoint
import com.palmcontrol.service.RemoteAccessibilityService

/**
 * 通过无障碍服务把控制端的手势/按键/文字注入被控端。
 * 坐标一律使用归一化 0..1，注入前映射到当前屏幕像素。
 */
object InputInjector {
    private val mainHandler = Handler(Looper.getMainLooper())
    private const val TAP_DURATION_MS = 80L
    private const val LONG_PRESS_DURATION_MS = 650L

    fun isReady(): Boolean = RemoteAccessibilityService.instance != null

    fun tap(x: Float, y: Float): Boolean = dispatch(
        listOf(StrokePoint(listOf(com.palmcontrol.net.NormalizedPoint(x, y)), 0, TAP_DURATION_MS))
    )

    fun longPress(x: Float, y: Float): Boolean = dispatch(
        listOf(
            StrokePoint(
                listOf(com.palmcontrol.net.NormalizedPoint(x, y)),
                0,
                LONG_PRESS_DURATION_MS
            )
        )
    )

    fun gesture(strokes: List<StrokePoint>): Boolean = dispatch(strokes)

    private fun dispatch(strokes: List<StrokePoint>): Boolean {
        val service = RemoteAccessibilityService.instance ?: return false
        if (strokes.isEmpty()) return false

        val bounds = screenBounds(service)
        if (bounds.width() <= 0 || bounds.height() <= 0) return false

        val maxStrokes = GestureDescription.getMaxStrokeCount()
        val maxDuration = GestureDescription.getMaxGestureDuration()

        val builder = GestureDescription.Builder()
        var added = 0
        for (stroke in strokes.take(maxStrokes)) {
            if (stroke.points.isEmpty()) continue
            val path = Path()
            stroke.points.forEachIndexed { index, point ->
                val px = bounds.left + point.x * bounds.width()
                val py = bounds.top + point.y * bounds.height()
                if (index == 0) {
                    path.moveTo(px, py)
                    if (stroke.points.size == 1) {
                        path.lineTo(px + 0.5f, py + 0.5f)
                    }
                } else {
                    path.lineTo(px, py)
                }
            }
            val start = stroke.startTimeMs.coerceIn(0L, maxDuration)
            val duration = stroke.durationMs.coerceIn(1L, maxDuration)
            if (start + duration > maxDuration) continue
            builder.addStroke(GestureDescription.StrokeDescription(path, start, duration))
            added++
        }
        if (added == 0) return false

        val description = builder.build()
        mainHandler.post {
            runCatching { service.dispatchGesture(description, null, null) }
        }
        return true
    }

    fun key(action: String): Boolean {
        val service = RemoteAccessibilityService.instance ?: return false
        val globalAction = when (action) {
            "back" -> AccessibilityServiceAction.BACK
            "home" -> AccessibilityServiceAction.HOME
            "recents" -> AccessibilityServiceAction.RECENTS
            "notifications" -> AccessibilityServiceAction.NOTIFICATIONS
            "quick_settings" -> AccessibilityServiceAction.QUICK_SETTINGS
            else -> return false
        }
        return runCatching { service.performGlobalAction(globalAction) }.getOrDefault(false)
    }

    fun text(value: String): Boolean {
        if (value.isEmpty()) return false
        val service = RemoteAccessibilityService.instance ?: return false
        val root = service.rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false

        val args = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                value
            )
        }
        if (focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true

        // 部分输入框不支持 ACTION_SET_TEXT，退回剪贴板粘贴。
        val clipboard = service.getSystemService(ClipboardManager::class.java)
        clipboard?.setPrimaryClip(ClipData.newPlainText("PalmControl", value))
        focused.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return focused.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    private fun screenBounds(service: RemoteAccessibilityService): Rect {
        val wm = service.getSystemService(WindowManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return wm.currentWindowMetrics.bounds
        }
        @Suppress("DEPRECATION")
        val display = wm.defaultDisplay
        val size = android.graphics.Point()
        display.getRealSize(size)
        return Rect(0, 0, size.x, size.y)
    }

    /** 避免直接依赖 AccessibilityService 常量，便于单测/阅读。 */
    private object AccessibilityServiceAction {
        const val BACK = android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
        const val HOME = android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
        const val RECENTS = android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS
        const val NOTIFICATIONS =
            android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
        const val QUICK_SETTINGS =
            android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
    }
}
