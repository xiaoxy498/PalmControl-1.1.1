package com.palmcontrol.util

import java.net.URI

/**
 * 把用户输入的地址规范成 WebSocket 地址。
 *
 * 支持的写法：
 *  192.168.1.10:8080          -> ws://192.168.1.10:8080/ws
 *  http://relay.example.com  -> ws://relay.example.com/ws
 *  https://relay.example.com -> wss://relay.example.com/ws
 *  wss://relay.example.com/custom -> 原样保留路径
 */
object ServerUrl {

    fun normalize(input: String): String? {
        val raw = input.trim()
        if (raw.isEmpty()) return null

        val withScheme = if (raw.contains("://")) raw else "ws://$raw"
        val uri = runCatching { URI(withScheme) }.getOrNull() ?: return null

        val scheme = when (uri.scheme?.lowercase()) {
            "ws" -> "ws"
            "wss" -> "wss"
            "http" -> "ws"
            "https" -> "wss"
            else -> return null
        }

        val host = uri.host ?: return null
        if (host.isBlank() || host.contains(' ')) return null

        val port = uri.port
        val portPart = if (port in 1..65535) ":$port" else ""

        var path = uri.path.orEmpty()
        if (path.isBlank() || path == "/") path = "/ws"

        return "$scheme://$host$portPart$path"
    }

    fun isValid(input: String): Boolean = normalize(input) != null

    /**
     * 把规范化后的 ws(s) 地址推导成 HTTP 基础地址，供 /api/chat 等接口使用。
     *
     *  ws://106.14.219.48:8080/ws   -> http://106.14.219.48:8080
     *  wss://relay.example.com/ws    -> https://relay.example.com
     */
    fun toHttpBase(input: String): String? {
        val normalized = normalize(input) ?: return null
        val uri = runCatching { URI(normalized) }.getOrNull() ?: return null
        val scheme = when (uri.scheme?.lowercase()) {
            "ws" -> "http"
            "wss" -> "https"
            else -> return null
        }
        val host = uri.host ?: return null
        val port = uri.port
        val portPart = if (port in 1..65535) ":$port" else ""
        return "$scheme://$host$portPart"
    }
}
