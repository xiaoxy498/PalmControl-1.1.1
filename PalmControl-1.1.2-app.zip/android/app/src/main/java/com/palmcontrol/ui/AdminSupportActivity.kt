package com.palmcontrol.ui

import android.os.Bundle
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.palmcontrol.R
import com.palmcontrol.databinding.ActivityAdminSupportBinding
import com.palmcontrol.util.ChatAttachment
import com.palmcontrol.util.Prefs
import com.palmcontrol.util.ServerUrl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class AdminSupportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdminSupportBinding
    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .build()
    }

    private var baseUrl: String? = null
    private var token: String? = null
    private var pollJob: Job? = null
    private var activeChatId: String? = null
    private var activeChatRefresh: (() -> Unit)? = null
    private var pendingSave: ChatAttachment? = null
    private val timeFormat = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())

    private val openAttachment =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) uploadAttachment(uri)
        }

    private val saveAttachment =
        registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
            val attachment = pendingSave
            pendingSave = null
            if (uri != null && attachment != null) saveAttachmentTo(uri, attachment)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminSupportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        (binding.toolbar as? MaterialToolbar)?.setNavigationOnClickListener { finish() }

        baseUrl = ServerUrl.toHttpBase(Prefs.load(this).serverUrl)
        if (baseUrl == null) {
            binding.tvStatus.setText(R.string.admin_no_server)
            binding.btnRefresh.isEnabled = false
            return
        }
        binding.btnRefresh.setOnClickListener {
            lifecycleScope.launch { refreshOnce() }
        }
        start()
    }

    override fun onDestroy() {
        pollJob?.cancel()
        super.onDestroy()
    }

    private fun start() {
        lifecycleScope.launch {
            binding.tvStatus.setText(R.string.support_typing)
            val ok = login()
            if (!ok) {
                binding.tvStatus.setText(R.string.admin_login_failed)
                return@launch
            }
            binding.tvStatus.text = ""
            warnIfServerOutdated()
            startPolling()
        }
    }

    /** 旧版服务端没有结束对话和附件接口，提前提示。 */
    private fun warnIfServerOutdated() {
        val base = baseUrl ?: return
        lifecycleScope.launch {
            val version = fetchServerVersion("$base/health") ?: return@launch
            if (version.isBlank()) toast(getString(R.string.support_server_outdated))
        }
    }

    private suspend fun fetchServerVersion(url: String): String? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url).get().build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                JSONObject(response.body?.string().orEmpty()).optString("version")
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = lifecycleScope.launch {
            while (isActive) {
                refreshOnce()
                delay(3000)
            }
        }
    }

    private suspend fun login(): Boolean = withContext(Dispatchers.IO) {
        val base = baseUrl ?: return@withContext false
        try {
            val payload = JSONObject()
                .put("username", ADMIN_USER)
                .put("password", ADMIN_PASSWORD)
            val request = Request.Builder()
                .url("$base/api/admin/login")
                .post(payload.toString().toRequestBody(JSON))
                .build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext false
                val json = JSONObject(response.body?.string().orEmpty())
                token = json.optString("token").takeIf { it.isNotBlank() }
                token != null
            }
        } catch (e: Exception) {
            false
        }
    }

    private suspend fun refreshOnce() {
        val handoffs = fetchHandoffs() ?: return
        renderHandoffs(handoffs)
        val pending = handoffs.count { it.optString("status") == "pending" }
        binding.tvStatus.text =
            if (pending > 0) getString(R.string.admin_pending) + "（$pending）" else ""
    }

    private suspend fun fetchHandoffs(): List<JSONObject>? = withContext(Dispatchers.IO) {
        val base = baseUrl ?: return@withContext null
        val auth = token ?: return@withContext null
        try {
            val request = Request.Builder()
                .url("$base/api/admin/handoffs")
                .header("authorization", "Bearer $auth")
                .get()
                .build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val raw = response.body?.string().orEmpty()
                val array: JSONArray = JSONObject(raw).optJSONArray("handoffs") ?: JSONArray()
                (0 until array.length()).mapNotNull { array.optJSONObject(it) }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun renderHandoffs(handoffs: List<JSONObject>) {
        binding.llHandoffs.removeAllViews()
        if (handoffs.isEmpty()) {
            binding.llHandoffs.addView(
                TextView(this).apply {
                    text = getString(R.string.admin_empty)
                    setTextColor(ContextCompat.getColor(this@AdminSupportActivity, R.color.text_secondary))
                    textSize = 14f
                    gravity = Gravity.CENTER
                    setPadding(0, dp(40), 0, 0)
                }
            )
            return
        }
        handoffs.forEach { addHandoffCard(it) }
    }

    private fun addHandoffCard(handoff: JSONObject) {
        val id = handoff.optString("id")
        val status = handoff.optString("status")
        val userName = handoff.optString("userName").ifBlank { "用户" }
        val preview = handoff.optString("preview")
        val createdAt = handoff.optLong("createdAt")

        val card = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
            radius = dp(14).toFloat()
            setCardBackgroundColor(ContextCompat.getColor(this@AdminSupportActivity, R.color.surface_card))
            strokeWidth = 0
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }

        val title = TextView(this).apply {
            text = when (status) {
                "pending" -> getString(R.string.admin_pending)
                "allowed" -> getString(R.string.admin_allowed)
                "closed" -> getString(R.string.admin_closed)
                else -> getString(R.string.admin_denied)
            }
            setTextColor(
                ContextCompat.getColor(
                    this@AdminSupportActivity,
                    if (status == "pending") R.color.warning_amber else R.color.text_secondary
                )
            )
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        val meta = TextView(this).apply {
            text = "$userName · ${timeFormat.format(Date(createdAt))}"
            setTextColor(ContextCompat.getColor(this@AdminSupportActivity, R.color.text_secondary))
            textSize = 12f
            setPadding(0, dp(4), 0, 0)
        }

        val message = TextView(this).apply {
            text = preview
            setTextColor(ContextCompat.getColor(this@AdminSupportActivity, R.color.text_primary))
            textSize = 14f
            setPadding(0, dp(8), 0, 0)
        }

        content.addView(title)
        content.addView(meta)
        content.addView(message)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, dp(10), 0, 0)
        }

        if (status == "pending") {
            actions.addView(
                actionButton(getString(R.string.admin_deny), outlined = true) {
                    decide(id, allow = false)
                }
            )
            actions.addView(
                actionButton(getString(R.string.admin_allow), outlined = false) {
                    decide(id, allow = true)
                }
            )
        } else if (status == "allowed") {
            actions.addView(
                actionButton(getString(R.string.admin_open_chat), outlined = false) {
                    openChat(id, userName)
                }
            )
        }

        content.addView(actions)
        card.addView(content)
        binding.llHandoffs.addView(card)
    }

    private fun actionButton(text: String, outlined: Boolean, onClick: () -> Unit): MaterialButton {
        val button = if (outlined) {
            MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        } else {
            MaterialButton(this)
        }
        button.text = text
        button.textSize = 13f
        button.minWidth = 0
        button.setPadding(dp(16), 0, dp(16), 0)
        button.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            dp(40)
        ).apply { marginStart = dp(8) }
        button.setOnClickListener { onClick() }
        return button
    }

    private fun decide(id: String, allow: Boolean) {
        lifecycleScope.launch {
            val ok = sendDecision(id, allow)
            if (ok) {
                toast(getString(R.string.admin_updated))
                refreshOnce()
            } else {
                toast(getString(R.string.admin_action_failed))
            }
        }
    }

    private suspend fun sendDecision(id: String, allow: Boolean): Boolean =
        withContext(Dispatchers.IO) {
            val base = baseUrl ?: return@withContext false
            val auth = token ?: return@withContext false
            try {
                val payload = JSONObject().put("allow", allow)
                val request = Request.Builder()
                    .url("$base/api/admin/handoffs/$id/decision")
                    .header("authorization", "Bearer $auth")
                    .post(payload.toString().toRequestBody(JSON))
                    .build()
                httpClient.newCall(request).execute().use { it.isSuccessful }
            } catch (e: Exception) {
                false
            }
        }

    private fun openChat(id: String, userName: String) {
        activeChatId = id
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), 0)
        }
        val scroll = ScrollView(this)
        val messageList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(messageList)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(280))
        )

        val input = EditText(this).apply {
            hint = getString(R.string.admin_reply_hint)
            setSingleLine(false)
            maxLines = 3
        }
        val sendButton = MaterialButton(this).apply {
            text = getString(R.string.send)
            minWidth = 0
        }
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        inputRow.addView(
            input,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        inputRow.addView(
            sendButton,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)).apply {
                marginStart = dp(8)
            }
        )
        val attachButton = actionButton(getString(R.string.support_upload), outlined = true) {
            activeChatId = id
            openAttachment.launch(arrayOf("*/*"))
        }
        root.addView(attachButton)
        root.addView(inputRow)

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("${getString(R.string.admin_chat_title)} · $userName")
            .setView(root)
            .setNegativeButton(R.string.close, null)
            .create()

        var job: Job? = null

        val render = { handoff: JSONObject ->
            val list = handoff.optJSONArray("messages") ?: JSONArray()
            messageList.removeAllViews()
            for (i in 0 until list.length()) {
                val msg = list.optJSONObject(i) ?: continue
                val text = msg.optString("text")
                if (text.isNotBlank()) {
                    messageList.addView(bubble(msg.optString("from"), text))
                }
                ChatAttachment.fromJson(msg.optJSONObject("attachment"))?.let { attachment ->
                    messageList.addView(
                        ChatAttachmentView.create(
                            this,
                            attachment,
                            isUser = msg.optString("from") == "user"
                        ) { requestSave(it) }
                    )
                }
            }
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }

        suspend fun refresh() {
            val handoff = fetchDetail(id) ?: return
            render(handoff)
            if (handoff.optString("status") == "closed") {
                toast(getString(R.string.admin_user_closed))
                dialog.dismiss()
            }
        }
        activeChatRefresh = {
            lifecycleScope.launch { refresh() }
        }

        sendButton.setOnClickListener {
            val text = input.text?.toString()?.trim().orEmpty()
            if (text.isEmpty()) return@setOnClickListener
            input.setText("")
            lifecycleScope.launch {
                val ok = sendAdminMessage(id, text)
                if (!ok) toast(getString(R.string.admin_send_failed))
                refresh()
            }
        }

        dialog.setOnDismissListener {
            job?.cancel()
            activeChatId = null
            activeChatRefresh = null
            lifecycleScope.launch { refreshOnce() }
        }
        dialog.show()

        job = lifecycleScope.launch {
            while (isActive && dialog.isShowing) {
                refresh()
                delay(2000)
            }
        }
    }

    private fun uploadAttachment(uri: Uri) {
        val id = activeChatId ?: return
        lifecycleScope.launch {
            try {
                val attachment = withContext(Dispatchers.IO) {
                    ChatAttachment.fromUri(this@AdminSupportActivity, uri)
                }
                val payload = JSONObject().put("attachment", attachment.toJson())
                when {
                    sendAdminPayload(id, payload) in 200..299 -> activeChatRefresh?.invoke()
                    else -> toast(getString(R.string.support_attachment_failed))
                }
            } catch (error: Exception) {
                toast(error.message ?: getString(R.string.support_attachment_failed))
            }
        }
    }

    private fun requestSave(attachment: ChatAttachment) {
        pendingSave = attachment
        saveAttachment.launch(attachment.name)
    }

    private fun saveAttachmentTo(uri: Uri, attachment: ChatAttachment) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    contentResolver.openOutputStream(uri)?.use { output ->
                        output.write(attachment.bytes())
                    } ?: return@runCatching false
                    true
                }.getOrDefault(false)
            }
            toast(
                getString(
                    if (ok) R.string.support_attachment_saved
                    else R.string.support_attachment_save_failed
                )
            )
        }
    }

    private suspend fun fetchDetail(id: String): JSONObject? = withContext(Dispatchers.IO) {
        val base = baseUrl ?: return@withContext null
        val auth = token ?: return@withContext null
        try {
            val request = Request.Builder()
                .url("$base/api/admin/handoffs/$id")
                .header("authorization", "Bearer $auth")
                .get()
                .build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                JSONObject(response.body?.string().orEmpty()).optJSONObject("handoff")
            }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun sendAdminMessage(id: String, text: String): Boolean =
        sendAdminPayload(id, JSONObject().put("text", text)) in 200..299

    /** 返回 HTTP 状态码，网络异常返回 0。 */
    private suspend fun sendAdminPayload(id: String, payload: JSONObject): Int =
        withContext(Dispatchers.IO) {
            val base = baseUrl ?: return@withContext 0
            val auth = token ?: return@withContext 0
            try {
                val request = Request.Builder()
                    .url("$base/api/admin/handoffs/$id/message")
                    .header("authorization", "Bearer $auth")
                    .post(payload.toString().toRequestBody(JSON))
                    .build()
                httpClient.newCall(request).execute().use { it.code }
            } catch (e: Exception) {
                0
            }
        }

    private fun bubble(from: String, text: String): View {
        val isUser = from == "user"
        val isSystem = from == "system"
        val view = TextView(this).apply {
            this.text = text
            textSize = if (isSystem) 12f else 14f
            setTextColor(
                ContextCompat.getColor(
                    this@AdminSupportActivity,
                    if (isSystem) R.color.text_secondary else R.color.text_primary
                )
            )
            setPadding(dp(12), dp(8), dp(12), dp(8))
            if (!isSystem) {
                setBackgroundResource(
                    if (isUser) R.drawable.bg_bubble_ai else R.drawable.bg_bubble_user
                )
            }
        }
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = if (isUser) Gravity.START else Gravity.END
            topMargin = dp(6)
            marginEnd = if (isUser) dp(32) else 0
            marginStart = if (isUser) 0 else dp(32)
        }
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (isUser) Gravity.START else Gravity.END
            addView(view, params)
        }
        return wrapper
    }

    private fun toast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private companion object {
        const val ADMIN_USER = "ADMIN"
        const val ADMIN_PASSWORD = "ADMIN123"
        val JSON = "application/json; charset=utf-8".toMediaType()
    }
}
