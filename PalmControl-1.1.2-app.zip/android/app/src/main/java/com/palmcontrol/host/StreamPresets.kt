package com.palmcontrol.host

data class StreamConfig(
    val targetWidth: Int,
    val jpegQuality: Int,
    val fps: Int
)

/** 画质/帧率预设，与 UI 中 Spinner 的顺序保持一致。 */
object StreamPresets {
    private val WIDTHS = intArrayOf(480, 720, 1080)
    private val JPEG_QUALITY = intArrayOf(45, 62, 78)
    val FPS = intArrayOf(10, 15, 20)

    fun create(qualityIndex: Int, fpsIndex: Int): StreamConfig {
        val q = qualityIndex.coerceIn(0, 2)
        val f = fpsIndex.coerceIn(0, 2)
        return StreamConfig(
            targetWidth = WIDTHS[q],
            jpegQuality = JPEG_QUALITY[q],
            fps = FPS[f]
        )
    }

    /** 按最大宽度等比缩小，不放大。 */
    fun outputSize(srcWidth: Int, srcHeight: Int, maxWidth: Int): IntArray {
        if (srcWidth <= 0 || srcHeight <= 0 || maxWidth <= 0) return intArrayOf(2, 2)
        if (srcWidth <= maxWidth) return intArrayOf(srcWidth, srcHeight)
        val height = (srcHeight.toLong() * maxWidth / srcWidth).toInt().coerceAtLeast(2)
        return intArrayOf(maxWidth, height)
    }
}
