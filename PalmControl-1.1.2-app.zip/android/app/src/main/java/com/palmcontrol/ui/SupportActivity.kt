package com.palmcontrol.ui

import android.os.Bundle
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.palmcontrol.R
import com.palmcontrol.databinding.ActivitySupportBinding
import com.palmcontrol.util.ChatAttachment
import com.palmcontrol.util.Prefs
import com.palmcontrol.util.ServerUrl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SupportActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySupportBinding
    private val messages = mutableListOf<ChatMessage>()
    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .build()
    }

    private var handoffId: String? = null
    private var handoffStatus: String = "none"
    private var pollJob: Job? = null
    private var renderedServerMessages = 0
    private var pendingSave: ChatAttachment? = null

    private val openAttachment =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) uploadAttachment(uri)
        }

    private val saveAttachment =
        registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
            val attachment = pendingSave
            pendingSave = null
            if (uri != null && attachment != null) saveAttachmentTo(uri, attachment)
        }

    data class ChatMessage(val role: String, val content: String)

    private data class ChatResult(
        val type: String,
        val reply: String,
        val handoffId: String?
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySupportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        (binding.toolbar as? MaterialToolbar)?.setNavigationOnClickListener { finish() }

        addMessage(ChatMessage("assistant", getString(R.string.support_welcome)))

        binding.btnSend.setOnClickListener { sendCurrent() }
        binding.btnHandoff.setOnClickListener {
            binding.etInput.setText(getString(R.string.support_handoff_text))
            sendCurrent()
        }
        binding.btnAttach.setOnClickListener {
            if (handoffId == null) {
                toast(getString(R.string.support_need_handoff))
            } else {
                openAttachment.launch(arrayOf("*/*"))
            }
        }
        binding.btnEndChat.setOnClickListener { closeConversation() }

        warnIfServerOutdated()
    }

    /** 旧版服务端没有 /close 和附件接口，提前提示，避免只看到“网络异常”。 */
    private fun warnIfServerOutdated() {
        val base = httpBase() ?: return
        lifecycleScope.launch {
            val version = fetchServerVersion("$base/health") ?: return@launch
            if (version.isBlank()) toast(getString(R.string.support_server_outdated))
        }
    }

    private suspend fun fetchServerVersion(url: String): String? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url).get().build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                JSONObject(response.body?.string().orEmpty()).optString("version")
            }
        } catch (e: Exception) {
            null
        }
    }

    override fun onDestroy() {
        pollJob?.cancel()
        super.onDestroy()
    }

    private fun sendCurrent() {
        val text = binding.etInput.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return
        binding.etInput.setText("")
        addMessage(ChatMessage("user", text))

        val base = httpBase() ?: run {
            addMessage(ChatMessage("assistant", getString(R.string.support_no_server)))
            return
        }

        val activeHandoff = handoffId
        if (activeHandoff != null && handoffStatus != "denied") {
            sendHandoffMessage(base, activeHandoff, text)
        } else {
            sendAiMessage(base, text)
        }
    }

    private fun sendAiMessage(base: String, text: String) {
        binding.btnSend.isEnabled = false
        lifecycleScope.launch {
            val typing = addBubble(getString(R.string.support_typing), isUser = false)
            val result = requestAiReply("$base/api/chat", text)
            removeBubble(typing)
            binding.btnSend.isEnabled = true

            if (result == null) {
                addMessage(ChatMessage("assistant", getString(R.string.support_network_error)))
                return@launch
            }
            addMessage(ChatMessage("assistant", result.reply))
            if (result.type == "handoff" && !result.handoffId.isNullOrBlank()) {
                enterHandoffMode(result.handoffId!!)
            }
        }
    }

    private fun sendHandoffMessage(base: String, id: String, text: String) {
        lifecycleScope.launch {
            val code = postHandoffMessage("$base/api/chat/handoff/$id/message", text)
            if (code !in 200..299) {
                addMessage(
                    ChatMessage(
                        "assistant",
                        getString(
                            if (code == 403) R.string.support_banned
                            else R.string.support_network_error
                        )
                    )
                )
            }
        }
    }

    private fun enterHandoffMode(id: String) {
        handoffId = id
        handoffStatus = "pending"
        renderedServerMessages = 0
        binding.handoffActions.isVisible = true
        startPolling()
    }

    private fun closeConversation() {
        val id = handoffId ?: return
        val base = httpBase() ?: return
        binding.btnEndChat.isEnabled = false
        lifecycleScope.launch {
            val code = postEmpty("$base/api/chat/handoff/$id/close")
            binding.btnEndChat.isEnabled = true
            when (code) {
                in 200..299 -> {
                    finishHandoffLocally()
                    toast(getString(R.string.support_back_to_ai))
                }
                404 -> toast(getString(R.string.support_server_outdated))
                409 -> {
                    finishHandoffLocally()
                    toast(getString(R.string.support_chat_closed))
                }
                403 -> toast(getString(R.string.support_banned))
                else -> toast(getString(R.string.support_network_error))
            }
        }
    }

    private fun finishHandoffLocally() {
        pollJob?.cancel()
        handoffId = null
        handoffStatus = "closed"
        renderedServerMessages = 0
        binding.handoffActions.isVisible = false
        addBubble(getString(R.string.support_chat_closed), isUser = false)
    }

    private fun uploadAttachment(uri: Uri) {
        val id = handoffId ?: return
        val base = httpBase() ?: return
        lifecycleScope.launch {
            try {
                val attachment = withContext(Dispatchers.IO) {
                    ChatAttachment.fromUri(this@SupportActivity, uri)
                }
                val payload = JSONObject().put("attachment", attachment.toJson())
                val code = postHandoffPayload("$base/api/chat/handoff/$id/message", payload)
                when (code) {
                    in 200..299 -> {
                        // 服务端确认成功后再显示，避免“本地上传成功、实际没发出去”。
                        binding.llMessages.addView(
                            ChatAttachmentView.create(this@SupportActivity, attachment, isUser = true) {
                                requestSave(it)
                            }
                        )
                        scrollToBottom()
                    }
                    404 -> toast(getString(R.string.support_server_outdated))
                    413 -> toast(getString(R.string.support_attachment_too_large))
                    409 -> toast(getString(R.string.support_chat_closed))
                    403 -> toast(getString(R.string.support_banned))
                    else -> toast(getString(R.string.support_attachment_failed))
                }
            } catch (error: Exception) {
                toast(error.message ?: getString(R.string.support_attachment_failed))
            }
        }
    }

    private fun requestSave(attachment: ChatAttachment) {
        pendingSave = attachment
        saveAttachment.launch(attachment.name)
    }

    private fun saveAttachmentTo(uri: Uri, attachment: ChatAttachment) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    contentResolver.openOutputStream(uri)?.use { output ->
                        output.write(attachment.bytes())
                    } ?: return@runCatching false
                    true
                }.getOrDefault(false)
            }
            toast(
                getString(
                    if (ok) R.string.support_attachment_saved
                    else R.string.support_attachment_save_failed
                )
            )
        }
    }

    private fun startPolling() {
        pollJob?.cancel()
        val base = httpBase() ?: return
        val id = handoffId ?: return
        pollJob = lifecycleScope.launch {
            while (isActive) {
                val handoff = fetchHandoff("$base/api/chat/handoff/$id")
                if (handoff != null) {
                    renderServerMessages(handoff)
                    val status = handoff.optString("status")
                    handoffStatus = status
                    if (status == "denied") {
                        handoffId = null
                        binding.handoffActions.isVisible = false
                        toast(getString(R.string.support_handoff_denied))
                        break
                    }
                    if (status == "closed") {
                        finishHandoffLocally()
                        break
                    }
                }
                delay(2000)
            }
        }
    }

    /** 只渲染来自管理员 / 系统的消息，用户自己的消息已在本地乐观展示。 */
    private fun renderServerMessages(handoff: JSONObject) {
        val list: JSONArray = handoff.optJSONArray("messages") ?: return
        for (i in renderedServerMessages until list.length()) {
            val msg = list.optJSONObject(i) ?: continue
            val from = msg.optString("from")
            if (from == "admin" || from == "system") {
                val text = msg.optString("text")
                if (text.isNotBlank()) addBubble(text, isUser = false)
                ChatAttachment.fromJson(msg.optJSONObject("attachment"))?.let { attachment ->
                    binding.llMessages.addView(
                        ChatAttachmentView.create(this, attachment, isUser = false) {
                            requestSave(it)
                        }
                    )
                    scrollToBottom()
                }
            }
        }
        renderedServerMessages = list.length()
    }

    private suspend fun requestAiReply(url: String, text: String): ChatResult? =
        withContext(Dispatchers.IO) {
            try {
                val payload = JSONObject().apply {
                    put("messages", JSONArray().apply {
                        messages.forEach {
                            put(JSONObject().put("role", it.role).put("content", it.content))
                        }
                    })
                    put("userName", Prefs.currentUser(this@SupportActivity) ?: "")
                }
                val request = authorize(Request.Builder().url(url))
                    .post(payload.toString().toRequestBody(JSON))
                    .build()
                httpClient.newCall(request).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withContext ChatResult(
                            "error",
                            when (response.code) {
                                403 -> getString(R.string.support_banned)
                                429 -> getString(R.string.support_rate_limited)
                                503 -> getString(R.string.support_unavailable)
                                else -> getString(R.string.support_network_error)
                            },
                            null
                        )
                    }
                    val json = JSONObject(raw)
                    ChatResult(
                        json.optString("type"),
                        json.optString("reply").ifBlank { getString(R.string.support_network_error) },
                        json.optString("handoffId").takeIf { it.isNotBlank() }
                    )
                }
            } catch (e: Exception) {
                null
            }
        }

    private suspend fun fetchHandoff(url: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val request = authorize(Request.Builder().url(url)).get().build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val raw = response.body?.string().orEmpty()
                JSONObject(raw).optJSONObject("handoff")
            }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun postHandoffMessage(url: String, text: String): Int =
        postHandoffPayload(url, JSONObject().put("text", text))

    private suspend fun postHandoffPayload(url: String, payload: JSONObject): Int =
        postRaw(url, payload)

    private suspend fun postEmpty(url: String): Int = postRaw(url, JSONObject())

    /** 返回 HTTP 状态码，网络异常返回 0。 */
    private suspend fun postRaw(url: String, payload: JSONObject): Int =
        withContext(Dispatchers.IO) {
            try {
                val request = authorize(Request.Builder().url(url))
                    .post(payload.toString().toRequestBody(JSON))
                    .build()
                httpClient.newCall(request).execute().use { response ->
                    response.code
                }
            } catch (e: Exception) {
                0
            }
        }

    /** 客服接口需要携带账号 token，服务端据此判断是否被封禁。 */
    private fun authorize(builder: Request.Builder): Request.Builder {
        val token = Prefs.authToken(this)
        return if (token.isNullOrBlank()) builder else builder.header("authorization", "Bearer $token")
    }

    private fun httpBase(): String? {
        val server = Prefs.load(this).serverUrl
        return ServerUrl.toHttpBase(server)
    }

    private fun addMessage(message: ChatMessage) {
        messages.add(message)
        addBubble(message.content, message.role == "user")
    }

    private fun addBubble(text: String, isUser: Boolean): View {
        val bubble = TextView(this).apply {
            this.text = text
            setTextColor(ContextCompat.getColor(this@SupportActivity, R.color.text_primary))
            textSize = 14f
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundResource(if (isUser) R.drawable.bg_bubble_user else R.drawable.bg_bubble_ai)
            setTextIsSelectable(true)
        }
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = if (isUser) Gravity.END else Gravity.START
            topMargin = dp(8)
            marginStart = if (isUser) dp(40) else 0
            marginEnd = if (isUser) 0 else dp(40)
        }
        binding.llMessages.addView(bubble, params)
        scrollToBottom()
        return bubble
    }

    private fun removeBubble(view: View) {
        binding.llMessages.removeView(view)
    }

    private fun scrollToBottom() {
        binding.scrollMessages.post {
            binding.scrollMessages.fullScroll(View.FOCUS_DOWN)
        }
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun toast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
    }

    private companion object {
        val JSON = "application/json; charset=utf-8".toMediaType()
    }
}
