package com.palmcontrol.net

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 对 OkHttp WebSocket 的极薄封装，被控端与控制端共用。
 * token 用于服务端识别账号：封禁账号会在信令握手时被拒绝。
 */
class RelayClient(
    private val url: String,
    private val listener: Listener,
    private val token: String? = null
) {
    interface Listener {
        fun onOpen()
        fun onText(payload: String)
        fun onBinary(payload: ByteArray)
        fun onClosed(reason: String)
        fun onFailure(reason: String)
    }

    private val userClosed = AtomicBoolean(false)

    @Volatile
    private var socket: WebSocket? = null

    fun connect() {
        val targetUrl = if (token.isNullOrBlank()) {
            url
        } else {
            val separator = if (url.contains('?')) '&' else '?'
            "$url${separator}token=${URLEncoder.encode(token, "UTF-8")}"
        }
        val request = try {
            Request.Builder().url(targetUrl).build()
        } catch (e: IllegalArgumentException) {
            listener.onFailure(e.message ?: "服务器地址无效")
            return
        }

        socket = httpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                listener.onOpen()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                listener.onText(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                listener.onBinary(bytes.toByteArray())
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (!userClosed.get()) {
                    listener.onClosed(reason.ifBlank { "连接已关闭" })
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (!userClosed.get()) {
                    listener.onFailure(t.message ?: "网络错误")
                }
            }
        })
    }

    fun sendText(payload: String): Boolean = socket?.send(payload) ?: false

    fun sendBinary(payload: ByteArray): Boolean {
        val bytes = payload.toByteString()
        return socket?.send(bytes) ?: false
    }

    fun close() {
        userClosed.set(true)
        socket?.close(1000, "client bye")
        socket = null
    }

    companion object {
        private val httpClient: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .pingInterval(20, TimeUnit.SECONDS)
                .build()
        }
    }
}
