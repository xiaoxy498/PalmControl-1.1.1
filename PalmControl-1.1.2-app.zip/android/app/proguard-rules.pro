# Keep OkHttp / Okio platform-specific hooks.
-dontwarn okhttp3.**
-dontwarn okio.**
