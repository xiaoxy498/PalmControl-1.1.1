#!/usr/bin/env node
import 'dotenv/config';
import http from 'node:http';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHash, randomBytes, randomInt, scryptSync, timingSafeEqual } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import nodemailer from 'nodemailer';
import { WebSocket, WebSocketServer } from 'ws';

const PIN_RE = /^(?:\d{4,6})$/;

function hashPin(pin) {
  return createHash('sha256').update(pin).digest('hex');
}

function cleanName(value, fallback) {
  if (typeof value !== 'string') return fallback;
  const cleaned = value.replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, 60);
  return cleaned || fallback;
}

/**
 * 创建中继服务器。可注入参数便于测试。
 */
export function createRelayServer(options = {}) {
  const roomTtlMs = options.roomTtlMs ?? 10 * 60 * 1000;
  const pendingTtlMs = options.pendingTtlMs ?? 60 * 1000;
  const maxFrameBytes = options.maxFrameBytes ?? 2 * 1024 * 1024;
  const maxTextBytes = options.maxTextBytes ?? 16 * 1024;
  const maxInputPerSecond = options.maxInputPerSecond ?? 120;
  const log = options.log ?? (() => {});

  // AI 客服（DeepSeek）相关配置
  const deepseekApiKey =
    options.deepseekApiKey ?? process.env.DEEPSEEK_API_KEY ?? '';
  const deepseekModel =
    options.deepseekModel ?? process.env.DEEPSEEK_MODEL ?? 'deepseek-chat';
  const deepseekBaseUrl =
    options.deepseekBaseUrl ??
    process.env.DEEPSEEK_BASE_URL ??
    'https://api.deepseek.com';
  const maxChatTokens = options.maxChatTokens ?? 300;
  const chatRequestTimeoutMs = options.chatRequestTimeoutMs ?? 20_000;
  const chatRateLimit = options.chatRateLimit ?? 10; // 每 IP 每分钟请求数
  const chatRateWindowMs = 60_000;
  const chatFetch = options.chatFetch ?? globalThis.fetch;

  // 管理员账号（用于处理转人工）
  const adminUsername =
    options.adminUsername ?? process.env.ADMIN_USERNAME ?? 'ADMIN';
  const adminPassword =
    options.adminPassword ?? process.env.ADMIN_PASSWORD ?? 'ADMIN123';
  const handoffTtlMs = options.handoffTtlMs ?? 24 * 60 * 60 * 1000;
  const adminTokenTtlMs = options.adminTokenTtlMs ?? 12 * 60 * 60 * 1000;
  const maxAttachmentBytes = options.maxAttachmentBytes ?? 3 * 1024 * 1024;

  // 供客户端检测服务端是否已更新（旧版本没有该字段）
  const serverVersion = options.serverVersion ?? '1.1.2';

  // 后台管理（网页）账号，仅用于管理用户，与 App 内的转人工管理员分开
  const consoleUsername =
    options.consoleUsername ?? process.env.CONSOLE_USERNAME ?? 'ADMIN';
  const consolePassword =
    options.consolePassword ?? process.env.CONSOLE_PASSWORD ?? 'admin123';
  const consoleTokenTtlMs = options.consoleTokenTtlMs ?? 12 * 60 * 60 * 1000;
  const userTokenTtlMs = options.userTokenTtlMs ?? 30 * 24 * 60 * 60 * 1000;
  const inboxLimit = 100;

  const moduleDir = path.dirname(fileURLToPath(import.meta.url));
  const dataDir = options.dataDir ?? process.env.DATA_DIR ?? path.join(moduleDir, '..', 'data');
  const storeFile = path.join(dataDir, 'store.json');
  const adminDir =
    options.adminDir ?? process.env.ADMIN_DIR ?? path.resolve(moduleDir, '..', '..', 'admin');

  // 网页后台单独监听一个端口，避免和 WebSocket 中继端口冲突。
  // false 表示不启动后台端口；0 表示随机端口（测试用）。
  const adminPortOption =
    options.adminPort ?? (process.env.ADMIN_PORT === undefined ? 8090 : process.env.ADMIN_PORT);
  const adminPort = adminPortOption === false ? false : Number(adminPortOption);
  let listeningAdminPort = 0;

  // SMTP（未配置时后台发邮件返回 503）
  const smtpHost = process.env.SMTP_HOST ?? '';
  const smtpPort = Number(process.env.SMTP_PORT ?? 465);
  const smtpSecure = (process.env.SMTP_SECURE ?? 'true') !== 'false';
  const smtpUser = process.env.SMTP_USER ?? '';
  const smtpPass = process.env.SMTP_PASS ?? '';
  const smtpFrom = process.env.SMTP_FROM ?? smtpUser;
  const smtpConfigured = Boolean(smtpHost && smtpUser && smtpPass);
  let mailTransport = null;

  const users = new Map(); // usernameLower -> user
  const userTokens = new Map(); // token -> { key, expiresAt }
  const inbox = new Map(); // usernameLower -> [message]
  const consoleTokens = new Map(); // token -> expiresAt
  let storeLoaded = false;

  async function loadStore() {
    if (storeLoaded) return;
    storeLoaded = true;
    try {
      const raw = await fs.readFile(storeFile, 'utf8');
      const data = JSON.parse(raw);
      for (const user of data.users ?? []) {
        if (user && typeof user.username === 'string' && user.salt && user.hash) {
          users.set(user.username.toLowerCase(), user);
        }
      }
      for (const [key, list] of Object.entries(data.messages ?? {})) {
        if (Array.isArray(list)) inbox.set(key, list);
      }
    } catch (error) {
      if (error.code !== 'ENOENT') log(`store load failed: ${error.message}`);
    }
  }

  async function saveStore() {
    const data = {
      users: [...users.values()],
      messages: Object.fromEntries(inbox)
    };
    try {
      await fs.mkdir(dataDir, { recursive: true });
      const tmp = `${storeFile}.tmp`;
      await fs.writeFile(tmp, JSON.stringify(data));
      await fs.rename(tmp, storeFile);
    } catch (error) {
      log(`store save failed: ${error.message}`);
    }
  }

  const storeReady = loadStore();

  function hashPassword(password) {
    const salt = randomBytes(16).toString('hex');
    return { salt, hash: scryptSync(String(password), salt, 32).toString('hex') };
  }

  function verifyPassword(password, user) {
    try {
      const actual = scryptSync(String(password), user.salt, 32);
      const expected = Buffer.from(user.hash, 'hex');
      return actual.length === expected.length && timingSafeEqual(actual, expected);
    } catch {
      return false;
    }
  }

  function validEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function publicUser(user) {
    const list = inbox.get(user.username.toLowerCase()) ?? [];
    return {
      username: user.username,
      email: user.email ?? '',
      banned: Boolean(user.banned),
      createdAt: user.createdAt ?? 0,
      unread: list.filter((m) => !m.read).length
    };
  }

  function issueUserToken(key) {
    const token = randomBytes(18).toString('hex');
    userTokens.set(token, { key, expiresAt: Date.now() + userTokenTtlMs });
    return token;
  }

  /** 校验用户 token，返回 { user } / { status, error }。封禁用户仍可通过，按功能单独限制。 */
  function authenticateUser(req) {
    const auth = req.headers.authorization;
    if (typeof auth !== 'string' || !auth.startsWith('Bearer ')) {
      return { status: 401, error: 'unauthorized' };
    }
    const token = auth.slice(7).trim();
    const session = userTokens.get(token);
    if (!session) return { status: 401, error: 'unauthorized' };
    if (Date.now() > session.expiresAt) {
      userTokens.delete(token);
      return { status: 401, error: 'unauthorized' };
    }
    const user = users.get(session.key);
    if (!user) return { status: 401, error: 'unauthorized' };
    return { user };
  }

  /** 封禁只限制远控、客服等功能，不影响登录、消息与设置。 */
  function bannedUser(req) {
    return Boolean(authenticateUser(req).user?.banned);
  }

  function isConsole(req) {
    const auth = req.headers.authorization;
    if (typeof auth !== 'string' || !auth.startsWith('Bearer ')) return false;
    const token = auth.slice(7).trim();
    const expiresAt = consoleTokens.get(token);
    if (!expiresAt) return false;
    if (Date.now() > expiresAt) {
      consoleTokens.delete(token);
      return false;
    }
    return true;
  }

  async function deliverMail({ to, subject, text }) {
    if (typeof options.sendMail === 'function') {
      return options.sendMail({ to, subject, text });
    }
    if (!smtpConfigured) {
      const error = new Error('smtp_not_configured');
      error.status = 503;
      throw error;
    }
    if (!mailTransport) {
      mailTransport = nodemailer.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure: smtpSecure,
        auth: { user: smtpUser, pass: smtpPass }
      });
    }
    return mailTransport.sendMail({ from: smtpFrom, to, subject, text });
  }

  async function handleRegister(req, res) {
    await storeReady;
    const { body, error } = await readBody(req);
    if (error || !body) {
      return sendJson(res, error || 400, { ok: false, error: 'bad_request' });
    }
    const username = String(body.username ?? '').trim();
    const password = String(body.password ?? '');
    const email = String(body.email ?? '').trim();
    if (username.length < 3 || username.length > 20 || /\s/.test(username)) {
      return sendJson(res, 400, { ok: false, error: 'invalid_username' });
    }
    if (username.toLowerCase() === 'admin') {
      return sendJson(res, 400, { ok: false, error: 'reserved_username' });
    }
    if (password.length < 6) {
      return sendJson(res, 400, { ok: false, error: 'invalid_password' });
    }
    if (!email && body.migrate !== true) {
      return sendJson(res, 400, { ok: false, error: 'email_required' });
    }
    if (email && !validEmail(email)) {
      return sendJson(res, 400, { ok: false, error: 'invalid_email' });
    }
    const key = username.toLowerCase();
    if (users.has(key)) {
      return sendJson(res, 409, { ok: false, error: 'user_exists' });
    }
    const user = {
      username,
      email,
      ...hashPassword(password),
      banned: false,
      createdAt: Date.now()
    };
    users.set(key, user);
    inbox.set(key, inbox.get(key) ?? []);
    await saveStore();
    log(`user registered ${username}`);
    return sendJson(res, 200, { ok: true, token: issueUserToken(key), user: publicUser(user) });
  }

  async function handleLogin(req, res) {
    await storeReady;
    const { body, error } = await readBody(req);
    if (error || !body) {
      return sendJson(res, error || 400, { ok: false, error: 'bad_request' });
    }
    const key = String(body.username ?? '').trim().toLowerCase();
    const user = users.get(key);
    if (!user || !verifyPassword(body.password ?? '', user)) {
      return sendJson(res, 401, { ok: false, error: 'invalid_credentials' });
    }
    // 封禁不拦截登录：用户仍可查看消息、公告和设置，只是远控与客服不可用。
    return sendJson(res, 200, { ok: true, token: issueUserToken(key), user: publicUser(user) });
  }

  async function handleMe(req, res) {
    await storeReady;
    const auth = authenticateUser(req);
    if (!auth.user) {
      return sendJson(res, auth.status, { ok: false, error: auth.error });
    }
    return sendJson(res, 200, { ok: true, user: publicUser(auth.user) });
  }

  async function handleMessages(req, res) {
    await storeReady;
    const auth = authenticateUser(req);
    if (!auth.user) {
      return sendJson(res, auth.status, { ok: false, error: auth.error });
    }
    const list = inbox.get(auth.user.username.toLowerCase()) ?? [];
    return sendJson(res, 200, { ok: true, messages: list, unread: list.filter((m) => !m.read).length });
  }

  async function handleMessageRead(req, res, id) {
    await storeReady;
    const auth = authenticateUser(req);
    if (!auth.user) {
      return sendJson(res, auth.status, { ok: false, error: auth.error });
    }
    const list = inbox.get(auth.user.username.toLowerCase()) ?? [];
    const target = list.find((m) => m.id === id);
    if (!target) return sendJson(res, 404, { ok: false, error: 'message_not_found' });
    target.read = true;
    await saveStore();
    return sendJson(res, 200, { ok: true });
  }

  async function handleConsoleLogin(req, res) {
    const { body, error } = await readBody(req);
    if (error || !body) {
      return sendJson(res, error || 400, { ok: false, error: 'bad_request' });
    }
    if (body.username !== consoleUsername || body.password !== consolePassword) {
      return sendJson(res, 401, { ok: false, error: 'invalid_credentials' });
    }
    const token = randomBytes(18).toString('hex');
    consoleTokens.set(token, Date.now() + consoleTokenTtlMs);
    return sendJson(res, 200, { ok: true, token });
  }

  async function handleConsoleUsers(req, res, url) {
    if (!isConsole(req)) {
      return sendJson(res, 401, { ok: false, error: 'unauthorized' });
    }
    await storeReady;
    const query = String(url.searchParams.get('query') ?? '').trim().toLowerCase();
    const items = [...users.values()]
      .filter(
        (user) =>
          !query ||
          user.username.toLowerCase().includes(query) ||
          String(user.email ?? '').toLowerCase().includes(query)
      )
      .sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0))
      .map(publicUser);
    return sendJson(res, 200, { ok: true, users: items });
  }

  async function handleConsoleOverview(req, res) {
    if (!isConsole(req)) {
      return sendJson(res, 401, { ok: false, error: 'unauthorized' });
    }
    await storeReady;
    const totalMem = os.totalmem();
    const usedMem = totalMem - os.freemem();
    const connections = [...rooms.values()].map((room) => ({
      code: room.code,
      hostName: room.hostName,
      hostIp: clientIp(room.host),
      controllerName: room.controller?.name ?? room.pending?.name ?? '',
      controllerIp: clientIp(room.controller?.ws ?? room.pending?.ws),
      status: room.controller ? 'connected' : room.pending ? 'pending' : 'waiting',
      durationSec: Math.max(
        0,
        Math.round((Date.now() - (room.pairedAt ?? room.createdAt)) / 1000)
      )
    }));
    return sendJson(res, 200, {
      ok: true,
      server: {
        version: serverVersion,
        uptimeSec: Math.round((Date.now() - startedAt) / 1000),
        cpuPercent: cpuPercent(),
        cpuCores: os.cpus().length,
        memory: {
          totalBytes: totalMem,
          usedBytes: usedMem,
          percent: totalMem ? Math.round((usedMem / totalMem) * 100) : 0,
          processBytes: process.memoryUsage().rss
        },
        traffic: { inBytes: relayStats.inBytes, outBytes: relayStats.outBytes },
        rooms: rooms.size,
        users: users.size,
        bannedUsers: [...users.values()].filter((user) => user.banned).length,
        unreadMessages: [...inbox.values()].reduce(
          (sum, list) => sum + list.filter((message) => !message.read).length,
          0
        )
      },
      nodes: await probeNodes(),
      connections
    });
  }

  async function handleConsoleAnnounce(req, res) {
    if (!isConsole(req)) {
      return sendJson(res, 401, { ok: false, error: 'unauthorized' });
    }
    await storeReady;
    const { body, error } = await readBody(req);
    if (error || !body) {
      return sendJson(res, error || 400, { ok: false, error: 'bad_request' });
    }
    const text = String(body.body ?? '').trim().slice(0, 2000);
    if (!text) return sendJson(res, 400, { ok: false, error: 'empty_message' });
    const title = String(body.title ?? '').trim().slice(0, 80) || '系统公告';
    const createdAt = Date.now();
    for (const key of users.keys()) {
      const list = inbox.get(key) ?? [];
      list.push({
        id: randomBytes(6).toString('hex'),
        title,
        body: text,
        createdAt,
        read: false,
        from: 'announcement'
      });
      if (list.length > inboxLimit) list.splice(0, list.length - inboxLimit);
      inbox.set(key, list);
    }
    if (users.size) await saveStore();
    log(`announcement sent to ${users.size} users`);
    return sendJson(res, 200, { ok: true, count: users.size, title });
  }

  async function handleConsoleBan(req, res, username) {
    if (!isConsole(req)) {
      return sendJson(res, 401, { ok: false, error: 'unauthorized' });
    }
    await storeReady;
    const { body, error } = await readBody(req);
    if (error || !body) {
      return sendJson(res, error || 400, { ok: false, error: 'bad_request' });
    }
    const user = users.get(String(username ?? '').toLowerCase());
    if (!user) return sendJson(res, 404, { ok: false, error: 'user_not_found' });
    user.banned = body.banned === true;
    await saveStore();
    log(`user ${user.username} banned=${user.banned}`);
    return sendJson(res, 200, { ok: true, user: publicUser(user) });
  }

  async function handleConsoleMessage(req, res, username) {
    if (!isConsole(req)) {
      return sendJson(res, 401, { ok: false, error: 'unauthorized' });
    }
    await storeReady;
    const { body, error } = await readBody(req);
    if (error || !body) {
      return sendJson(res, error || 400, { ok: false, error: 'bad_request' });
    }
    const user = users.get(String(username ?? '').toLowerCase());
    if (!user) return sendJson(res, 404, { ok: false, error: 'user_not_found' });
    const text = String(body.body ?? '').trim().slice(0, 2000);
    if (!text) return sendJson(res, 400, { ok: false, error: 'empty_message' });
    const key = user.username.toLowerCase();
    const list = inbox.get(key) ?? [];
    const message = {
      id: randomBytes(6).toString('hex'),
      title: String(body.title ?? '').trim().slice(0, 80) || '系统消息',
      body: text,
      createdAt: Date.now(),
      read: false,
      from: 'admin'
    };
    list.push(message);
    if (list.length > inboxLimit) list.splice(0, list.length - inboxLimit);
    inbox.set(key, list);
    await saveStore();
    return sendJson(res, 200, { ok: true, message });
  }

  async function handleConsoleEmail(req, res, username) {
    if (!isConsole(req)) {
      return sendJson(res, 401, { ok: false, error: 'unauthorized' });
    }
    await storeReady;
    const { body, error } = await readBody(req);
    if (error || !body) {
      return sendJson(res, error || 400, { ok: false, error: 'bad_request' });
    }
    const user = users.get(String(username ?? '').toLowerCase());
    if (!user) return sendJson(res, 404, { ok: false, error: 'user_not_found' });
    if (!user.email) return sendJson(res, 400, { ok: false, error: 'no_email' });
    const text = String(body.body ?? '').trim().slice(0, 4000);
    if (!text) return sendJson(res, 400, { ok: false, error: 'empty_message' });
    try {
      await deliverMail({
        to: user.email,
        subject: String(body.subject ?? '').trim().slice(0, 120) || 'PalmControl 通知',
        text
      });
    } catch (mailError) {
      return sendJson(res, mailError.status || 502, {
        ok: false,
        error: mailError.message || 'mail_failed'
      });
    }
    log(`mail sent to ${user.username}`);
    return sendJson(res, 200, { ok: true });
  }

  async function handleAdminPage(res) {
    try {
      const html = await fs.readFile(path.join(adminDir, 'index.html'), 'utf8');
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
      res.end(html);
    } catch {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      res.end('admin page not found. Set ADMIN_DIR to the folder containing index.html.');
    }
  }

  const startedAt = Date.now();

  // 监控统计：中继 WebSocket 收发字节数，进程启动后累计。
  const relayStats = { inBytes: 0, outBytes: 0 };
  let listeningRelayPort = 0;

  function byteSize(data) {
    if (typeof data === 'string') return Buffer.byteLength(data);
    if (data && typeof data.byteLength === 'number') return data.byteLength;
    return 0;
  }

  function sampleCpu() {
    return os.cpus().reduce(
      (acc, cpu) => {
        const t = cpu.times;
        acc.idle += t.idle;
        acc.total += t.user + t.nice + t.sys + t.idle + t.irq;
        return acc;
      },
      { idle: 0, total: 0 }
    );
  }

  let lastCpuSample = sampleCpu();

  /** 两次采样之间的整机 CPU 占用率。 */
  function cpuPercent() {
    const now = sampleCpu();
    const idle = now.idle - lastCpuSample.idle;
    const total = now.total - lastCpuSample.total;
    lastCpuSample = now;
    if (total <= 0) return 0;
    return Math.max(0, Math.min(100, Math.round((1 - idle / total) * 100)));
  }

  // FRP 节点：FRP_NODES="主节点=http://ip:8080,备用=ws://ip:8080/ws"
  function toHttpBase(rawUrl) {
    let url = String(rawUrl ?? '').trim().replace(/\/+$/, '');
    if (/^wss:/i.test(url)) url = `https:${url.slice(4)}`;
    else if (/^ws:/i.test(url)) url = `http:${url.slice(3)}`;
    if (!/^https?:/i.test(url)) url = `http://${url}`;
    return url.replace(/\/ws$/i, '');
  }

  const nodeConfig = String(options.nodes ?? process.env.FRP_NODES ?? '')
    .split(',')
    .map((entry) => entry.trim())
    .filter(Boolean)
    .map((entry) => {
      const index = entry.indexOf('=');
      const name = index > 0 ? entry.slice(0, index).trim() : '';
      const rawUrl = index > 0 ? entry.slice(index + 1).trim() : entry;
      return { name: name || rawUrl, url: toHttpBase(rawUrl) };
    })
    .filter((node) => node.url);
  let nodeCache = { at: 0, list: [] };

  function nodeList() {
    if (nodeConfig.length) return nodeConfig;
    const port = listeningRelayPort || 8080;
    return [{ name: '主节点', url: `http://127.0.0.1:${port}` }];
  }

  async function probeNodes() {
    if (nodeCache.list.length && Date.now() - nodeCache.at < 8_000) return nodeCache.list;
    const list = await Promise.all(
      nodeList().map(async (node) => {
        const started = Date.now();
        try {
          const response = await fetch(`${node.url}/health`, {
            signal: AbortSignal.timeout(3_000)
          });
          return {
            ...node,
            online: response.ok,
            latencyMs: response.ok ? Date.now() - started : null
          };
        } catch {
          return { ...node, online: false, latencyMs: null };
        }
      })
    );
    nodeCache = { at: Date.now(), list };
    return list;
  }

  function clientIp(ws) {
    const raw = ws?._socket?.remoteAddress ?? '';
    return raw.replace(/^::ffff:/, '');
  }

  const rooms = new Map();
  const chatRateCounters = new Map();
  const handoffs = new Map();
  const adminTokens = new Map();

  // 允许 AI 回答的关键词（仅远控 / PalmControl 相关）
  const REMOTE_KEYWORDS = [
    '远控', '远程', '控制', '被控', '掌控', 'palmcontrol',
    '配对', '配对码', 'pin', '连接', '连不上', '断开', '断线',
    '黑屏', '画面', '屏幕', '共享', '投屏', '录屏',
    '操作', '点击', '滑动', '手势', '无障碍',
    '画质', '帧率', '延迟', '卡顿', '花屏',
    '服务器', 'ws', 'wss', '端口', '部署', '中继',
    '安装', '闪退', '崩溃', '权限', '授权',
    '设备', '安卓', 'android', 'app', '应用',
    '账号', '登录', '注册', '密码', '设置', '版本'
  ];

  // 转人工关键词
  const HANDOFF_KEYWORDS = [
    '转人工', '人工客服', '人工服务', '找人工', '真人客服', '真人', '人工'
  ];

  // 寒暄类：放行并交给模型简短回应，不算“无关问题”
  const GREETING_KEYWORDS = [
    '你好', '您好', '嗨', '哈喽', 'hello', 'hi', '在吗', '在么',
    '早上好', '中午好', '下午好', '晚上好', '谢谢', '感谢', '再见', '拜拜'
  ];

  const SYSTEM_PROMPT = [
    '你是 PalmControl（掌控）的 AI 客服，只回答与 PalmControl 手机远控相关的使用问题。',
    'PalmControl 是一款手机控制手机的远程协助工具，包含被控端（共享屏幕）和控制端（输入配对码远程操作）。',
    '只回答以下范围内的问题：配对码、PIN、连接失败、黑屏/无画面、无障碍服务、画质帧率、服务器地址、权限授权、安装闪退、账号设置等使用问题。',
    '用户打招呼（你好、在吗）、道谢或道别时，用一句友好简短的话回应，并提示你可以解答远控相关问题，不要拒绝。',
    '如果问题与远控无关（例如数学题、闲聊、其他软件、编程、翻译等），必须只用一句话回复：“暂不支持回答这类问题，我只能解答 PalmControl 远控相关的使用问题。”',
    '回答要简洁、具体、可操作，不要编造功能。不知道就说“这个问题我暂时无法回答，可以转人工客服。”',
    '禁止输出代码块、HTML、链接以外的复杂格式。'
  ].join('\n');

  const REFUSE_REPLY =
    '暂不支持回答这类问题，我只能解答 PalmControl 远控相关的使用问题。';

  const HANDOFF_REPLY =
    '已收到你的转人工请求，已提交给管理员确认，请稍候。';

  async function readBody(req, limitBytes = 16 * 1024) {
    const chunks = [];
    let size = 0;
    for await (const chunk of req) {
      size += chunk.length;
      if (size > limitBytes) return { error: 413 };
      chunks.push(chunk);
    }
    try {
      return { body: JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}') };
    } catch {
      return { error: 400 };
    }
  }

  function pruneHandoffs() {
    const now = Date.now();
    for (const [id, handoff] of handoffs) {
      if (now - handoff.createdAt > handoffTtlMs) handoffs.delete(id);
    }
  }

  function createHandoff(message, userName) {
    pruneHandoffs();
    const id = randomBytes(6).toString('hex');
    const handoff = {
      id,
      createdAt: Date.now(),
      status: 'pending',
      userName: cleanName(userName, '用户'),
      messages: [{ from: 'user', text: message, ts: Date.now() }]
    };
    handoffs.set(id, handoff);
    log(`handoff created id=${id} user=${handoff.userName}`);
    return handoff;
  }

  function handoffView(handoff) {
    const last = handoff.messages[handoff.messages.length - 1];
    const preview = last
      ? last.text || (last.attachment?.mime?.startsWith('image/') ? '[图片]' : '[文件]')
      : '';
    return {
      id: handoff.id,
      createdAt: handoff.createdAt,
      status: handoff.status,
      userName: handoff.userName,
      preview,
      messages: handoff.messages
    };
  }

  function parseAttachment(raw) {
    if (raw == null) return null;
    if (typeof raw !== 'object' || typeof raw.data !== 'string') {
      const error = new Error('invalid_attachment');
      error.status = 400;
      throw error;
    }
    const base64 = raw.data.replace(/^data:[^;]+;base64,/, '').trim();
    if (!base64) {
      const error = new Error('invalid_attachment');
      error.status = 400;
      throw error;
    }
    const bytes = Buffer.from(base64, 'base64');
    if (!bytes.length || bytes.length > maxAttachmentBytes) {
      const error = new Error('attachment_too_large');
      error.status = 413;
      throw error;
    }
    const mime = typeof raw.mime === 'string' && /^[\w.+-]+\/[\w.+-]+$/.test(raw.mime)
      ? raw.mime
      : 'application/octet-stream';
    return {
      name: cleanName(raw.name, '附件'),
      mime,
      data: bytes.toString('base64')
    };
  }

  function addHandoffMessage(handoff, from, text, rawAttachment = null) {
    const clean = String(text || '').trim().slice(0, 500);
    const attachment = parseAttachment(rawAttachment);
    if (!clean && !attachment) return null;
    const msg = { from, text: clean, ts: Date.now() };
    if (attachment) msg.attachment = attachment;
    handoff.messages.push(msg);
    return msg;
  }

  function issueAdminToken() {
    const token = randomBytes(18).toString('hex');
    adminTokens.set(token, Date.now() + adminTokenTtlMs);
    return token;
  }

  function isAdmin(req) {
    const auth = req.headers.authorization;
    if (typeof auth !== 'string' || !auth.startsWith('Bearer ')) return false;
    const token = auth.slice(7).trim();
    const expiresAt = adminTokens.get(token);
    if (!expiresAt) return false;
    if (Date.now() > expiresAt) {
      adminTokens.delete(token);
      return false;
    }
    return true;
  }

  function sendJson(res, status, payload) {
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(payload));
  }

  function clientIp(req) {
    const fwd = req.headers['x-forwarded-for'];
    if (typeof fwd === 'string' && fwd.trim()) {
      return fwd.split(',')[0].trim();
    }
    return req.socket.remoteAddress || 'unknown';
  }

  function rateLimitOk(ip) {
    const now = Date.now();
    const bucket = chatRateCounters.get(ip);
    if (!bucket || now > bucket.resetAt) {
      chatRateCounters.set(ip, { count: 1, resetAt: now + chatRateWindowMs });
      return true;
    }
    if (bucket.count >= chatRateLimit) return false;
    bucket.count += 1;
    return true;
  }

  function hasAny(text, keywords) {
    const lower = text.toLowerCase();
    return keywords.some((k) => lower.includes(k.toLowerCase()));
  }

  async function callDeepseek(messages, tokenLimit = maxChatTokens) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), chatRequestTimeoutMs);
    try {
      const resp = await chatFetch(`${deepseekBaseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${deepseekApiKey}`
        },
        body: JSON.stringify({
          model: deepseekModel,
          messages,
          temperature: 0.3,
          max_tokens: tokenLimit
        }),
        signal: controller.signal
      });
      const data = await resp.json();
      if (!resp.ok) {
        const msg = data?.error?.message || `DeepSeek HTTP ${resp.status}`;
        throw new Error(msg);
      }
      return data.choices?.[0]?.message?.content || '';
    } finally {
      clearTimeout(timer);
    }
  }

  async function handleChat(req, res) {
    const json = (status, payload) => sendJson(res, status, payload);

    const ip = clientIp(req);
    if (!rateLimitOk(ip)) {
      return json(429, {
        type: 'rate_limited',
        reply: '请求过于频繁，请稍后再试。'
      });
    }

    // 封禁用户的客服与转人工请求直接拒绝（登录、消息不受影响）
    await storeReady;
    if (bannedUser(req)) {
      return json(403, { type: 'error', error: 'banned', reply: '账号已被限制使用' });
    }

    const { body, error } = await readBody(req);
    if (error === 413) {
      return json(413, { type: 'error', reply: '请求内容过长。' });
    }
    if (error || !body) {
      return json(400, { type: 'error', reply: '请求格式不正确。' });
    }

    let message = '';
    if (Array.isArray(body.messages) && body.messages.length) {
      const last = body.messages[body.messages.length - 1];
      message = typeof last?.content === 'string' ? last.content : '';
    }
    if (!message && typeof body.message === 'string') {
      message = body.message;
    }
    message = message.trim().slice(0, 500);
    if (!message) {
      return json(400, { type: 'error', reply: '请输入你要咨询的问题。' });
    }

    // 转人工：创建待管理员确认的请求
    if (hasAny(message, HANDOFF_KEYWORDS)) {
      const handoff = createHandoff(message, body.userName);
      return json(200, {
        type: 'handoff',
        handoffId: handoff.id,
        reply: HANDOFF_REPLY
      });
    }

    // 关键词门禁：寒暄类放行，非远控问题直接拒绝，不消耗 API
    const isGreeting = hasAny(message, GREETING_KEYWORDS);
    if (!isGreeting && !hasAny(message, REMOTE_KEYWORDS)) {
      return json(200, { type: 'refuse', reply: REFUSE_REPLY });
    }

    // 远控问题才调用 DeepSeek；未配置 Key 时返回 503
    if (!deepseekApiKey) {
      return json(503, {
        type: 'unavailable',
        reply: '客服服务暂不可用，请稍后再试。'
      });
    }

    const messages = [
      { role: 'system', content: SYSTEM_PROMPT },
      ...(Array.isArray(body.messages)
        ? body.messages
            .filter((m) => m && typeof m.content === 'string')
            .slice(-10)
        : [{ role: 'user', content: message }])
    ];

    try {
      // 寒暄只给很短的回答，避免浪费额度
      const reply =
        (await callDeepseek(messages, isGreeting ? 60 : maxChatTokens)).trim() ||
        REFUSE_REPLY;
      return json(200, { type: 'reply', reply });
    } catch (error) {
      log(`deepseek error: ${error.message}`);
      return json(502, {
        type: 'error',
        reply: '客服服务暂时不可用，请稍后再试。'
      });
    }
  }

  function findHandoff(id) {
    return handoffs.get(String(id || ''));
  }

  async function handleUserHandoffStatus(req, res, id) {
    await storeReady;
    if (bannedUser(req)) {
      return sendJson(res, 403, { ok: false, error: 'banned', reply: '账号已被限制使用' });
    }
    const handoff = findHandoff(id);
    if (!handoff) {
      return sendJson(res, 404, { ok: false, error: 'handoff_not_found' });
    }
    return sendJson(res, 200, { ok: true, handoff: handoffView(handoff) });
  }

  async function handleUserHandoffMessage(req, res, id) {
    await storeReady;
    if (bannedUser(req)) {
      return sendJson(res, 403, { ok: false, error: 'banned', reply: '账号已被限制使用' });
    }
    const handoff = findHandoff(id);
    if (!handoff) {
      return sendJson(res, 404, { ok: false, error: 'handoff_not_found' });
    }
    if (handoff.status === 'denied' || handoff.status === 'closed') {
      return sendJson(res, 409, { ok: false, error: `handoff_${handoff.status}` });
    }
    const { body, error } = await readBody(req, maxAttachmentBytes * 2 + 64 * 1024);
    if (error || !body) {
      return sendJson(res, error || 400, { ok: false, error: 'bad_request' });
    }
    let msg;
    try {
      msg = addHandoffMessage(handoff, 'user', body.text ?? body.message, body.attachment);
    } catch (attachmentError) {
      return sendJson(res, attachmentError.status || 400, {
        ok: false,
        error: attachmentError.message
      });
    }
    if (!msg) return sendJson(res, 400, { ok: false, error: 'empty_message' });
    return sendJson(res, 200, { ok: true, handoff: handoffView(handoff) });
  }

  async function handleUserHandoffClose(req, res, id) {
    await storeReady;
    if (bannedUser(req)) {
      return sendJson(res, 403, { ok: false, error: 'banned', reply: '账号已被限制使用' });
    }
    const handoff = findHandoff(id);
    if (!handoff) {
      return sendJson(res, 404, { ok: false, error: 'handoff_not_found' });
    }
    if (handoff.status === 'denied') {
      return sendJson(res, 409, { ok: false, error: 'handoff_denied' });
    }
    if (handoff.status !== 'closed') {
      handoff.status = 'closed';
      addHandoffMessage(handoff, 'system', '用户已结束对话。');
      log(`handoff ${handoff.id} closed by user`);
    }
    return sendJson(res, 200, { ok: true, handoff: handoffView(handoff) });
  }

  async function handleAdminLogin(req, res) {
    const { body, error } = await readBody(req);
    if (error || !body) {
      return sendJson(res, 400, { ok: false, error: 'bad_request' });
    }
    if (body.username !== adminUsername || body.password !== adminPassword) {
      return sendJson(res, 401, { ok: false, error: 'invalid_credentials' });
    }
    return sendJson(res, 200, {
      ok: true,
      token: issueAdminToken(),
      username: adminUsername
    });
  }

  function handleAdminList(req, res) {
    if (!isAdmin(req)) {
      return sendJson(res, 401, { ok: false, error: 'unauthorized' });
    }
    pruneHandoffs();
    const items = [...handoffs.values()]
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 50)
      .map(handoffView);
    return sendJson(res, 200, { ok: true, handoffs: items });
  }

  async function handleAdminDecision(req, res, id) {
    if (!isAdmin(req)) {
      return sendJson(res, 401, { ok: false, error: 'unauthorized' });
    }
    const handoff = findHandoff(id);
    if (!handoff) {
      return sendJson(res, 404, { ok: false, error: 'handoff_not_found' });
    }
    if (handoff.status !== 'pending') {
      return sendJson(res, 409, { ok: false, error: 'already_decided' });
    }
    const { body, error } = await readBody(req);
    if (error || !body) {
      return sendJson(res, 400, { ok: false, error: 'bad_request' });
    }
    if (body.allow === true) {
      handoff.status = 'allowed';
      addHandoffMessage(handoff, 'system', '转人工已被允许，人工客服已接入。');
    } else {
      handoff.status = 'denied';
      addHandoffMessage(handoff, 'system', '转人工已被拒绝。');
    }
    log(`handoff ${handoff.id} ${handoff.status}`);
    return sendJson(res, 200, { ok: true, handoff: handoffView(handoff) });
  }

  async function handleAdminMessage(req, res, id) {
    if (!isAdmin(req)) {
      return sendJson(res, 401, { ok: false, error: 'unauthorized' });
    }
    const handoff = findHandoff(id);
    if (!handoff) {
      return sendJson(res, 404, { ok: false, error: 'handoff_not_found' });
    }
    if (handoff.status !== 'allowed') {
      return sendJson(res, 409, { ok: false, error: 'not_allowed' });
    }
    const { body, error } = await readBody(req, maxAttachmentBytes * 2 + 64 * 1024);
    if (error || !body) {
      return sendJson(res, error || 400, { ok: false, error: 'bad_request' });
    }
    let msg;
    try {
      msg = addHandoffMessage(handoff, 'admin', body.text ?? body.message, body.attachment);
    } catch (attachmentError) {
      return sendJson(res, attachmentError.status || 400, {
        ok: false,
        error: attachmentError.message
      });
    }
    if (!msg) return sendJson(res, 400, { ok: false, error: 'empty_message' });
    return sendJson(res, 200, { ok: true, handoff: handoffView(handoff) });
  }

  async function handleAdminDetail(req, res, id) {
    if (!isAdmin(req)) {
      return sendJson(res, 401, { ok: false, error: 'unauthorized' });
    }
    const handoff = findHandoff(id);
    if (!handoff) {
      return sendJson(res, 404, { ok: false, error: 'handoff_not_found' });
    }
    return sendJson(res, 200, { ok: true, handoff: handoffView(handoff) });
  }

  function handleHttpRequest(req, res) {
    let path = '/';
    let parsedUrl = null;
    try {
      parsedUrl = new URL(req.url || '/', 'http://localhost');
      path = parsedUrl.pathname;
    } catch {
      path = req.url || '/';
    }

    const fail = (error) => {
      log(`api error: ${error.message}`);
      if (!res.headersSent) {
        sendJson(res, 500, { ok: false, error: 'server_error' });
      }
    };

    if (req.method === 'GET' && path === '/health') {
      return sendJson(res, 200, {
        ok: true,
        version: serverVersion,
        rooms: rooms.size,
        handoffs: handoffs.size,
        users: users.size,
        adminPort: listeningAdminPort || (adminPort === false ? 0 : adminPort),
        uptimeSec: Math.round((Date.now() - startedAt) / 1000)
      });
    }
    if (req.method === 'POST' && path === '/api/chat') {
      return handleChat(req, res).catch(fail);
    }
    if (req.method === 'POST' && path === '/api/admin/login') {
      return handleAdminLogin(req, res).catch(fail);
    }
    if (req.method === 'GET' && path === '/api/admin/handoffs') {
      return handleAdminList(req, res);
    }

    // 账号与 App 消息
    if (req.method === 'POST' && path === '/api/auth/register') {
      return handleRegister(req, res).catch(fail);
    }
    if (req.method === 'POST' && path === '/api/auth/login') {
      return handleLogin(req, res).catch(fail);
    }
    if (req.method === 'GET' && path === '/api/auth/me') {
      return handleMe(req, res).catch(fail);
    }
    if (req.method === 'GET' && path === '/api/messages') {
      return handleMessages(req, res).catch(fail);
    }
    let consoleMatch = path.match(/^\/api\/messages\/([^/]+)\/read$/);
    if (consoleMatch && req.method === 'POST') {
      return handleMessageRead(req, res, decodeURIComponent(consoleMatch[1])).catch(fail);
    }

    // 网页后台
    if (
      req.method === 'GET' &&
      (path === '/admin' || path === '/admin/' || path === '/admin/index.html')
    ) {
      return handleAdminPage(res).catch(fail);
    }
    if (req.method === 'POST' && path === '/api/console/login') {
      return handleConsoleLogin(req, res).catch(fail);
    }
    if (req.method === 'GET' && path === '/api/console/users') {
      return handleConsoleUsers(req, res, parsedUrl).catch(fail);
    }
    if (req.method === 'GET' && path === '/api/console/overview') {
      return handleConsoleOverview(req, res).catch(fail);
    }
    if (req.method === 'POST' && path === '/api/console/announce') {
      return handleConsoleAnnounce(req, res).catch(fail);
    }
    consoleMatch = path.match(/^\/api\/console\/users\/([^/]+)\/ban$/);
    if (consoleMatch && req.method === 'POST') {
      return handleConsoleBan(req, res, decodeURIComponent(consoleMatch[1])).catch(fail);
    }
    consoleMatch = path.match(/^\/api\/console\/users\/([^/]+)\/message$/);
    if (consoleMatch && req.method === 'POST') {
      return handleConsoleMessage(req, res, decodeURIComponent(consoleMatch[1])).catch(fail);
    }
    consoleMatch = path.match(/^\/api\/console\/users\/([^/]+)\/email$/);
    if (consoleMatch && req.method === 'POST') {
      return handleConsoleEmail(req, res, decodeURIComponent(consoleMatch[1])).catch(fail);
    }

    let match = path.match(/^\/api\/chat\/handoff\/([^/]+)\/close$/);
    if (match && req.method === 'POST') {
      return handleUserHandoffClose(req, res, match[1]).catch(fail);
    }
    match = path.match(/^\/api\/chat\/handoff\/([^/]+)\/message$/);
    if (match && req.method === 'POST') {
      return handleUserHandoffMessage(req, res, match[1]).catch(fail);
    }
    match = path.match(/^\/api\/chat\/handoff\/([^/]+)$/);
    if (match && req.method === 'GET') {
      return handleUserHandoffStatus(req, res, match[1]).catch(fail);
    }

    match = path.match(/^\/api\/admin\/handoffs\/([^/]+)\/decision$/);
    if (match && req.method === 'POST') {
      return handleAdminDecision(req, res, match[1]).catch(fail);
    }
    match = path.match(/^\/api\/admin\/handoffs\/([^/]+)\/message$/);
    if (match && req.method === 'POST') {
      return handleAdminMessage(req, res, match[1]).catch(fail);
    }
    match = path.match(/^\/api\/admin\/handoffs\/([^/]+)$/);
    if (match && req.method === 'GET') {
      return handleAdminDetail(req, res, match[1]).catch(fail);
    }

    if (req.method === 'GET' && path === '/') {
      res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' });
      res.end(
        'PalmControl relay server\n' +
          'WebSocket endpoint: /ws\n' +
          'Health check: /health\n' +
          'AI chat: POST /api/chat\n' +
          'Admin: POST /api/admin/login, GET /api/admin/handoffs\n' +
          'Console: /admin\n'
      );
      return;
    }
    sendJson(res, 404, { ok: false, error: 'not_found' });
  }

  const httpServer = http.createServer(handleHttpRequest);
  // 网页后台（/admin 与 /api/console/*）走独立端口，同样复用上面的请求处理。
  const adminServer = http.createServer(handleHttpRequest);

  const wss = new WebSocketServer({
    server: httpServer,
    path: '/ws',
    maxPayload: maxFrameBytes + maxTextBytes
  });

  function send(ws, payload) {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(payload));
    }
  }

  function sendError(ws, code, message) {
    send(ws, { type: 'error', code, message });
  }

  function scheduleRoomExpiry(room) {
    if (room.expiryTimer) clearTimeout(room.expiryTimer);
    room.expiryTimer = setTimeout(() => {
      if (room.controller) return;
      sendError(room.host, 'room_expired', 'Pairing code expired. Start sharing again.');
      try {
        room.host.close(4001, 'room expired');
      } catch {
        /* ignore */
      }
      rooms.delete(room.code);
      log(`room ${room.code} expired`);
    }, roomTtlMs);
    room.expiryTimer.unref?.();
  }

  function stopController(room, reason) {
    const controller = room.controller;
    room.controller = null;
    room.sessionId = null;
    room.pairedAt = null;
    if (controller) {
      try {
        controller.ws.close(4000, reason);
      } catch {
        /* ignore */
      }
    }
  }

  async function handleHostRegister(ws, msg) {
    await ws.authReady;
    if (ws.banned) {
      rejectBanned(ws);
      return;
    }
    if (ws.role) {
      sendError(ws, 'already_registered', 'This connection is already registered.');
      return;
    }
    const deviceName = cleanName(msg.deviceName, 'Android');
    const pin = typeof msg.pin === 'string' ? msg.pin.trim() : '';
    if (pin && !PIN_RE.test(pin)) {
      sendError(ws, 'invalid_pin', 'PIN must be 4-6 digits.');
      return;
    }

    let code = '';
    for (let i = 0; i < 30; i++) {
      const candidate = String(randomInt(100000, 1000000));
      if (!rooms.has(candidate)) {
        code = candidate;
        break;
      }
    }
    if (!code) {
      sendError(ws, 'server_busy', 'Could not allocate a pairing code. Try again.');
      return;
    }

    const room = {
      code,
      host: ws,
      hostName: deviceName,
      pinHash: pin ? hashPin(pin) : null,
      createdAt: Date.now(),
      pairedAt: null,
      expiryTimer: null,
      pending: null,
      controller: null,
      sessionId: null
    };
    rooms.set(code, room);
    ws.role = 'host';
    ws.room = room;

    scheduleRoomExpiry(room);
    send(ws, {
      type: 'host.registered',
      code,
      expiresInSec: Math.floor(roomTtlMs / 1000)
    });
    log(`host registered code=${code} name=${deviceName}`);
  }

  async function handleControllerJoin(ws, msg) {
    await ws.authReady;
    if (ws.banned) {
      rejectBanned(ws);
      return;
    }
    if (ws.role) {
      sendError(ws, 'already_joined', 'This connection is already in a room.');
      return;
    }
    const code = typeof msg.code === 'string' ? msg.code.trim() : '';
    const room = rooms.get(code);
    if (!room) {
      sendError(ws, 'room_not_found', 'Pairing code not found or expired.');
      return;
    }
    const pin = typeof msg.pin === 'string' ? msg.pin.trim() : '';
    if (room.pinHash && (!pin || hashPin(pin) !== room.pinHash)) {
      sendError(ws, 'invalid_pin', 'Pairing PIN is incorrect.');
      return;
    }
    if (room.pending || room.controller) {
      sendError(ws, 'host_busy', 'The host is already in a session.');
      return;
    }

    const controllerId = randomBytes(6).toString('hex');
    const controllerName = cleanName(msg.deviceName, 'Controller');
    const timer = setTimeout(() => {
      if (room.pending && room.pending.id === controllerId) {
        sendError(ws, 'join_timeout', 'Host did not respond in time.');
        room.pending = null;
        try {
          ws.close(4404, 'join timeout');
        } catch {
          /* ignore */
        }
      }
    }, pendingTtlMs);
    timer.unref?.();

    room.pending = { id: controllerId, ws, name: controllerName, timer };
    ws.role = 'controller';
    ws.room = room;
    ws.controllerId = controllerId;

    send(ws, { type: 'join.pending' });
    send(room.host, {
      type: 'join.request',
      controllerId,
      deviceName: controllerName
    });
    log(`join request code=${code} controller=${controllerName}`);
  }

  function handleJoinDecision(ws, msg) {
    const room = ws.room;
    if (ws.role !== 'host' || !room) return;
    const pending = room.pending;
    if (!pending || pending.id !== String(msg.controllerId ?? '')) {
      sendError(ws, 'stale_decision', 'This request is no longer valid.');
      return;
    }
    clearTimeout(pending.timer);
    room.pending = null;

    if (msg.allow === true) {
      room.controller = { id: pending.id, ws: pending.ws, name: pending.name };
      room.sessionId = randomBytes(8).toString('hex');
      room.pairedAt = Date.now();
      if (room.expiryTimer) {
        clearTimeout(room.expiryTimer);
        room.expiryTimer = null;
      }
      send(room.host, {
        type: 'paired',
        role: 'host',
        peerName: pending.name,
        sessionId: room.sessionId
      });
      send(pending.ws, {
        type: 'paired',
        role: 'controller',
        peerName: room.hostName,
        sessionId: room.sessionId
      });
      log(`paired code=${room.code} controller=${pending.name}`);
    } else {
      pending.ws.controllerId = null;
      sendError(pending.ws, 'denied', String(msg.reason || 'Host denied the request.'));
      try {
        pending.ws.close(4403, 'denied');
      } catch {
        /* ignore */
      }
      log(`denied code=${room.code} controller=${pending.name}`);
    }
  }

  function allowRate(ws) {
    const now = Date.now();
    if (now - ws.rateWindow >= 1000) {
      ws.rateWindow = now;
      ws.rateCount = 0;
    }
    ws.rateCount += 1;
    return ws.rateCount <= maxInputPerSecond;
  }

  function relayTextFromHost(ws, text, msg) {
    const room = ws.room;
    if (!room) return;

    if (msg.type === 'join.decision') {
      handleJoinDecision(ws, msg);
      return;
    }
    if (!room.controller || !room.sessionId) return;

    if (msg.type === 'session.end') {
      send(room.controller.ws, { type: 'session.end', reason: msg.reason ?? '' });
      stopController(room, 'session ended');
      scheduleRoomExpiry(room);
      return;
    }
    if (room.controller.ws.readyState === WebSocket.OPEN) {
      room.controller.ws.send(text);
    }
  }

  function relayTextFromController(ws, text, msg) {
    const room = ws.room;
    if (!room || !room.controller || room.controller.ws !== ws) return;
    if (msg.type !== 'input.gesture' && msg.type !== 'input.key' &&
        msg.type !== 'input.text' && msg.type !== 'session.end') {
      return;
    }
    if (!allowRate(ws)) return;

    if (msg.type === 'session.end') {
      send(room.host, { type: 'session.end', reason: msg.reason ?? '' });
      stopController(room, 'session ended');
      scheduleRoomExpiry(room);
      return;
    }
    send(room.host, msg);
  }

  function handleText(ws, rawText) {
    if (Buffer.byteLength(rawText) > maxTextBytes) {
      ws.close(1009, 'message too large');
      return;
    }
    let msg;
    try {
      msg = JSON.parse(rawText);
    } catch {
      sendError(ws, 'bad_request', 'Invalid JSON.');
      return;
    }
    if (!msg || typeof msg.type !== 'string') {
      sendError(ws, 'bad_request', 'Missing message type.');
      return;
    }

    if (!ws.role) {
      if (msg.type === 'host.register') {
        handleHostRegister(ws, msg).catch(() =>
          sendError(ws, 'server_error', 'Internal server error.')
        );
      } else if (msg.type === 'controller.join') {
        handleControllerJoin(ws, msg).catch(() =>
          sendError(ws, 'server_error', 'Internal server error.')
        );
      } else {
        sendError(ws, 'not_registered', 'Register or join first.');
      }
      return;
    }
    if (ws.role === 'host') {
      relayTextFromHost(ws, rawText, msg);
    } else {
      relayTextFromController(ws, rawText, msg);
    }
  }

  function handleBinary(ws, data) {
    const room = ws.room;
    if (!room || ws.role !== 'host' || !room.controller || !room.sessionId) return;
    const controller = room.controller.ws;
    if (controller.readyState !== WebSocket.OPEN) return;
    if (data.length > maxFrameBytes) return;
    controller.send(data, { binary: true });
  }

  function handleClose(ws) {
    const room = ws.room;
    if (!room) return;

    if (ws === room.host) {
      if (room.pending) {
        clearTimeout(room.pending.timer);
        sendError(room.pending.ws, 'host_left', 'Host disconnected.');
        try {
          room.pending.ws.close(4401, 'host left');
        } catch {
          /* ignore */
        }
        room.pending = null;
      }
      if (room.controller) {
        send(room.controller.ws, { type: 'peer.left', reason: 'Host disconnected.' });
        try {
          room.controller.ws.close(4401, 'host left');
        } catch {
          /* ignore */
        }
        room.controller = null;
      }
      if (room.expiryTimer) clearTimeout(room.expiryTimer);
      rooms.delete(room.code);
      log(`room closed code=${room.code}`);
      return;
    }

    if (room.pending && room.pending.ws === ws) {
      clearTimeout(room.pending.timer);
      room.pending = null;
      log(`pending cancelled code=${room.code}`);
      return;
    }
    if (room.controller && room.controller.ws === ws) {
      room.controller = null;
      room.sessionId = null;
      room.pairedAt = null;
      send(room.host, { type: 'peer.left', reason: 'Controller disconnected.' });
      scheduleRoomExpiry(room);
      log(`controller left code=${room.code}`);
    }
  }

  /** 封禁只拒绝远控信令，不阻断登录和消息。 */
  function rejectBanned(ws) {
    if (ws.bannedRejected) return;
    ws.bannedRejected = true;
    sendError(ws, 'banned', '账号已被限制使用');
    try {
      ws.close(4403, 'banned');
    } catch {
      /* ignore */
    }
    log('banned client rejected');
  }

  wss.on('connection', (ws, req) => {
    ws.isAlive = true;
    ws.role = null;
    ws.room = null;
    ws.controllerId = null;
    ws.rateWindow = 0;
    ws.rateCount = 0;
    ws.banned = false;
    ws.bannedRejected = false;

    // 统计中继出站字节（JSON 文本与 JPEG 帧）。
    const rawSend = ws.send.bind(ws);
    ws.send = (data, ...args) => {
      relayStats.outBytes += byteSize(data);
      return rawSend(data, ...args);
    };

    // WebSocket 握手时通过 ?token= 校验账号；封禁用户直接拒绝远控连接。
    ws.authReady = storeReady.then(() => {
      let token = '';
      try {
        token = new URL(req?.url ?? '/', 'http://localhost').searchParams.get('token') ?? '';
      } catch {
        token = '';
      }
      if (!token) return;
      const session = userTokens.get(token);
      if (!session || Date.now() > session.expiresAt) return;
      const user = users.get(session.key);
      if (user?.banned) ws.banned = true;
    });
    ws.authReady.then(() => {
      if (ws.banned) rejectBanned(ws);
    });

    const roleTimer = setTimeout(() => {
      if (!ws.role) {
        sendError(ws, 'not_registered', 'Register or join first.');
        ws.close(4408, 'role required');
      }
    }, 10_000);
    roleTimer.unref?.();

    ws.on('pong', () => {
      ws.isAlive = true;
    });
    ws.on('message', (data, isBinary) => {
      relayStats.inBytes += byteSize(data);
      try {
        if (isBinary) {
          handleBinary(ws, data);
        } else {
          handleText(ws, data.toString());
        }
      } catch (error) {
        log(`message error: ${error.message}`);
        sendError(ws, 'server_error', 'Internal server error.');
      }
    });
    ws.on('close', () => {
      clearTimeout(roleTimer);
      handleClose(ws);
    });
    ws.on('error', (error) => log(`ws error: ${error.message}`));
  });

  const heartbeat = setInterval(() => {
    for (const ws of wss.clients) {
      if (ws.isAlive === false) {
        ws.terminate();
        continue;
      }
      ws.isAlive = false;
      try {
        ws.ping();
      } catch {
        /* ignore */
      }
    }
  }, 30_000);
  heartbeat.unref?.();

  function listen(port = 8080, host = '0.0.0.0', consolePort = adminPort) {
    return new Promise((resolve, reject) => {
      const onRelayError = (error) => reject(error);
      httpServer.once('error', onRelayError);
      httpServer.listen(port, host, async () => {
        httpServer.off('error', onRelayError);
        if (consolePort !== false) {
          try {
            await new Promise((done, failed) => {
              adminServer.once('error', failed);
              adminServer.listen(Number(consolePort), host, () => {
                adminServer.off('error', failed);
                done();
              });
            });
          } catch (error) {
            httpServer.closeAllConnections?.();
            httpServer.close(() => {});
            reject(error);
            return;
          }
        }
        listeningAdminPort = adminServer.listening ? adminServer.address().port : 0;
        const address = httpServer.address();
        if (address && typeof address === 'object') {
          listeningRelayPort = address.port;
          address.adminPort = listeningAdminPort;
        }
        resolve(address);
      });
    });
  }

  async function close() {
    clearInterval(heartbeat);
    for (const room of rooms.values()) {
      if (room.expiryTimer) clearTimeout(room.expiryTimer);
      if (room.pending) clearTimeout(room.pending.timer);
    }
    rooms.clear();
    for (const ws of wss.clients) {
      try {
        ws.terminate();
      } catch {
        /* ignore */
      }
    }
    await new Promise((resolve) => wss.close(() => resolve()));
    if (adminServer.listening) {
      adminServer.closeAllConnections?.();
      await new Promise((resolve) => adminServer.close(() => resolve()));
    }
    httpServer.closeAllConnections?.();
    await new Promise((resolve) => httpServer.close(() => resolve()));
  }

  return { httpServer, adminServer, wss, rooms, listen, close };
}

const isMain = process.argv[1] &&
  import.meta.url === pathToFileURL(process.argv[1]).href;

if (isMain) {
  const port = Number(process.env.PORT || 8080);
  const host = process.env.HOST || '0.0.0.0';
  const roomTtlMs = Number(process.env.ROOM_TTL_MS || 10 * 60 * 1000);
  const maxFrameBytes = Number(process.env.MAX_FRAME_BYTES || 2 * 1024 * 1024);

  const relay = createRelayServer({
    roomTtlMs,
    maxFrameBytes,
    log: (line) => console.log(`${new Date().toISOString()} ${line}`)
  });

  relay.listen(port, host).then((address) => {
    console.log(`PalmControl relay listening on ws://${address.address}:${address.port}/ws`);
    if (address.adminPort) {
      console.log(
        `PalmControl console listening on http://${address.address}:${address.adminPort}/admin`
      );
    }
  }).catch((error) => {
    console.error('Failed to start relay:', error);
    process.exit(1);
  });

  const shutdown = () => {
    console.log('Shutting down...');
    relay.close().finally(() => process.exit(0));
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}
