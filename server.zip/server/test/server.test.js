import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { WebSocket } from 'ws';
import { createRelayServer } from '../src/server.js';

async function startServer() {
  const relay = createRelayServer({ roomTtlMs: 60_000, pendingTtlMs: 5_000, adminPort: false });
  const address = await relay.listen(0, '127.0.0.1');
  return { relay, url: `ws://127.0.0.1:${address.port}/ws` };
}

async function open(url) {
  const ws = new WebSocket(url);
  await once(ws, 'open');
  return ws;
}

function waitJson(ws) {
  return new Promise((resolve, reject) => {
    const onMessage = (data, isBinary) => {
      if (isBinary) return;
      cleanup();
      try {
        resolve(JSON.parse(data.toString()));
      } catch (error) {
        reject(error);
      }
    };
    const onError = (error) => {
      cleanup();
      reject(error);
    };
    const cleanup = () => {
      ws.off('message', onMessage);
      ws.off('error', onError);
    };
    ws.on('message', onMessage);
    ws.on('error', onError);
  });
}

function waitBinary(ws) {
  return new Promise((resolve) => {
    const onMessage = (data, isBinary) => {
      if (!isBinary) return;
      ws.off('message', onMessage);
      resolve(data);
    };
    ws.on('message', onMessage);
  });
}

async function registerHost(host) {
  host.send(JSON.stringify({ type: 'host.register', deviceName: 'Pixel', pin: '1234' }));
  const registered = await waitJson(host);
  assert.equal(registered.type, 'host.registered');
  assert.match(registered.code, /^\d{6}$/);
  return registered;
}

async function joinAndApprove(host, controller, code) {
  const pendingPromise = waitJson(controller);
  const requestPromise = waitJson(host);
  controller.send(
    JSON.stringify({
      type: 'controller.join',
      code,
      pin: '1234',
      deviceName: 'Tablet'
    })
  );
  const [pending, request] = await Promise.all([pendingPromise, requestPromise]);
  assert.equal(pending.type, 'join.pending');
  assert.equal(request.type, 'join.request');

  const hostPairedPromise = waitJson(host);
  const controllerPairedPromise = waitJson(controller);
  host.send(
    JSON.stringify({
      type: 'join.decision',
      controllerId: request.controllerId,
      allow: true
    })
  );
  const [hostPaired, controllerPaired] = await Promise.all([
    hostPairedPromise,
    controllerPairedPromise
  ]);
  assert.equal(hostPaired.type, 'paired');
  assert.equal(controllerPaired.type, 'paired');
}

test('pairing relays input text and video frames', async () => {
  const { relay, url } = await startServer();
  const clients = [];
  try {
    const host = await open(url);
    clients.push(host);
    const registered = await registerHost(host);

    const controller = await open(url);
    clients.push(controller);
    await joinAndApprove(host, controller, registered.code);

    const hostInputPromise = waitJson(host);
    controller.send(
      JSON.stringify({
        type: 'input.gesture',
        strokes: [{ start: 0, duration: 100, points: [[0.5, 0.5]] }]
      })
    );
    const input = await hostInputPromise;
    assert.equal(input.type, 'input.gesture');

    const framePromise = waitBinary(controller);
    host.send(Buffer.from([0xff, 0xd8, 0x01]));
    const frame = await framePromise;
    assert.equal(frame.length, 3);
  } finally {
    for (const client of clients) client.terminate();
    await relay.close();
  }
});

test('wrong PIN is rejected and a retry can succeed', async () => {
  const { relay, url } = await startServer();
  const clients = [];
  try {
    const host = await open(url);
    clients.push(host);
    const registered = await registerHost(host);

    const controller = await open(url);
    clients.push(controller);
    controller.send(
      JSON.stringify({
        type: 'controller.join',
        code: registered.code,
        pin: '0000',
        deviceName: 'Tablet'
      })
    );
    const error = await waitJson(controller);
    assert.equal(error.type, 'error');
    assert.equal(error.code, 'invalid_pin');

    const pendingPromise = waitJson(controller);
    const requestPromise = waitJson(host);
    controller.send(
      JSON.stringify({
        type: 'controller.join',
        code: registered.code,
        pin: '1234',
        deviceName: 'Tablet'
      })
    );
    const [pending, request] = await Promise.all([pendingPromise, requestPromise]);
    assert.equal(pending.type, 'join.pending');
    assert.equal(request.type, 'join.request');
  } finally {
    for (const client of clients) client.terminate();
    await relay.close();
  }
});

test('host denies a request', async () => {
  const { relay, url } = await startServer();
  const clients = [];
  try {
    const host = await open(url);
    clients.push(host);
    const registered = await registerHost(host);

    const controller = await open(url);
    clients.push(controller);
    const pendingPromise = waitJson(controller);
    const requestPromise = waitJson(host);
    controller.send(
      JSON.stringify({
        type: 'controller.join',
        code: registered.code,
        pin: '1234',
        deviceName: 'Tablet'
      })
    );
    const [, request] = await Promise.all([pendingPromise, requestPromise]);

    const errorPromise = waitJson(controller);
    host.send(
      JSON.stringify({
        type: 'join.decision',
        controllerId: request.controllerId,
        allow: false,
        reason: 'Not now'
      })
    );
    const error = await errorPromise;
    assert.equal(error.type, 'error');
    assert.equal(error.code, 'denied');
  } finally {
    for (const client of clients) client.terminate();
    await relay.close();
  }
});

test('controller is notified when the host disconnects', async () => {
  const { relay, url } = await startServer();
  const clients = [];
  try {
    const host = await open(url);
    clients.push(host);
    const registered = await registerHost(host);

    const controller = await open(url);
    clients.push(controller);
    await joinAndApprove(host, controller, registered.code);

    const peerLeftPromise = waitJson(controller);
    host.terminate();
    const peerLeft = await peerLeftPromise;
    assert.equal(peerLeft.type, 'peer.left');
  } finally {
    for (const client of clients) client.terminate();
    await relay.close();
  }
});

test('health endpoint reports room count', async () => {
  const { relay, url } = await startServer();
  try {
    const response = await fetch(url.replace('ws://', 'http://').replace('/ws', '/health'));
    assert.equal(response.status, 200);
    const body = await response.json();
    assert.equal(body.ok, true);
  } finally {
    await relay.close();
  }
});

async function startChatServer(options = {}) {
  const relay = createRelayServer({ roomTtlMs: 60_000, adminPort: false, ...options });
  const address = await relay.listen(0, '127.0.0.1');
  return { relay, base: `http://127.0.0.1:${address.port}` };
}

async function postJson(base, body) {
  return fetch(`${base}/api/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body)
  });
}

test('chat refuses non-remote questions without calling DeepSeek', async () => {
  let called = false;
  const { relay, base } = await startChatServer({
    deepseekApiKey: 'sk-test',
    chatFetch: async () => {
      called = true;
      return new Response(JSON.stringify({}), { status: 200 });
    }
  });
  try {
    const res = await postJson(base, { message: '1+1等于几？' });
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.equal(data.type, 'refuse');
    assert.match(data.reply, /暂不支持/);
    assert.equal(called, false, 'DeepSeek should not be called for math questions');
  } finally {
    await relay.close();
  }
});

test('chat allows greetings to reach DeepSeek', async () => {
  let received = null;
  const { relay, base } = await startChatServer({
    deepseekApiKey: 'sk-test',
    chatFetch: async (url, init) => {
      received = JSON.parse(init.body);
      return new Response(
        JSON.stringify({
          choices: [{ message: { role: 'assistant', content: '你好，我是 PalmControl AI 客服，可以问我远控相关问题。' } }]
        }),
        { status: 200, headers: { 'content-type': 'application/json' } }
      );
    }
  });
  try {
    const res = await postJson(base, { message: '你好' });
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.equal(data.type, 'reply');
    assert.match(data.reply, /你好/);
    assert.ok(received, 'DeepSeek should be called for greetings');
    assert.equal(received.max_tokens, 60);
  } finally {
    await relay.close();
  }
});

test('admin allows a handoff and both sides can chat', async () => {
  const { relay, base } = await startChatServer({ deepseekApiKey: 'sk-test' });
  try {
    // 用户发起转人工
    const created = await (await postJson(base, { message: '我要转人工', userName: '小明' })).json();
    assert.equal(created.type, 'handoff');
    assert.match(created.handoffId, /^[0-9a-f]+$/);

    // 错误密码登录失败
    const badLogin = await fetch(`${base}/api/admin/login`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ username: 'ADMIN', password: 'wrong' })
    });
    assert.equal(badLogin.status, 401);

    // 正确登录
    const login = await fetch(`${base}/api/admin/login`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ username: 'ADMIN', password: 'ADMIN123' })
    });
    assert.equal(login.status, 200);
    const { token } = await login.json();
    assert.ok(token);

    // 未授权访问
    const unauthorized = await fetch(`${base}/api/admin/handoffs`);
    assert.equal(unauthorized.status, 401);

    // 管理员看到待处理请求
    const list = await fetch(`${base}/api/admin/handoffs`, {
      headers: { authorization: `Bearer ${token}` }
    });
    const listBody = await list.json();
    assert.equal(listBody.handoffs.length, 1);
    assert.equal(listBody.handoffs[0].status, 'pending');
    assert.equal(listBody.handoffs[0].userName, '小明');

    // 允许
    const decision = await fetch(`${base}/api/admin/handoffs/${created.handoffId}/decision`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
      body: JSON.stringify({ allow: true })
    });
    assert.equal(decision.status, 200);
    const decisionBody = await decision.json();
    assert.equal(decisionBody.handoff.status, 'allowed');

    // 用户轮询看到“已被允许”
    const statusRes = await fetch(`${base}/api/chat/handoff/${created.handoffId}`);
    const statusBody = await statusRes.json();
    assert.equal(statusBody.handoff.status, 'allowed');
    assert.ok(
      statusBody.handoff.messages.some((m) => m.text.includes('转人工已被允许'))
    );

    // 管理员发消息，用户能看到
    await fetch(`${base}/api/admin/handoffs/${created.handoffId}/message`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
      body: JSON.stringify({ text: '你好，我是人工客服。' })
    });
    const afterAdmin = await (await fetch(`${base}/api/chat/handoff/${created.handoffId}`)).json();
    assert.ok(afterAdmin.handoff.messages.some((m) => m.from === 'admin' && m.text.includes('人工客服')));

    // 用户回复，管理员能看到
    await fetch(`${base}/api/chat/handoff/${created.handoffId}/message`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ text: '远控还是连不上' })
    });
    const detail = await (await fetch(`${base}/api/admin/handoffs/${created.handoffId}`, {
      headers: { authorization: `Bearer ${token}` }
    })).json();
    assert.ok(detail.handoff.messages.some((m) => m.from === 'user' && m.text.includes('连不上')));
  } finally {
    await relay.close();
  }
});

test('admin can reject a handoff', async () => {
  const { relay, base } = await startChatServer({ deepseekApiKey: 'sk-test' });
  try {
    const created = await (await postJson(base, { message: '转人工' })).json();
    const login = await fetch(`${base}/api/admin/login`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ username: 'ADMIN', password: 'ADMIN123' })
    });
    const { token } = await login.json();

    const decision = await fetch(`${base}/api/admin/handoffs/${created.handoffId}/decision`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
      body: JSON.stringify({ allow: false })
    });
    assert.equal(decision.status, 200);

    const statusBody = await (await fetch(`${base}/api/chat/handoff/${created.handoffId}`)).json();
    assert.equal(statusBody.handoff.status, 'denied');
    assert.ok(statusBody.handoff.messages.some((m) => m.text.includes('转人工已被拒绝')));

    // 被拒绝后用户再发消息应返回 409
    const send = await fetch(`${base}/api/chat/handoff/${created.handoffId}/message`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ text: '还在吗' })
    });
    assert.equal(send.status, 409);
  } finally {
    await relay.close();
  }
});

test('handoff supports attachments and user can close the chat', async () => {
  const { relay, base } = await startChatServer({ deepseekApiKey: 'sk-test' });
  try {
    const created = await (await postJson(base, { message: '转人工' })).json();
    const login = await fetch(`${base}/api/admin/login`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ username: 'ADMIN', password: 'ADMIN123' })
    });
    const { token } = await login.json();
    await fetch(`${base}/api/admin/handoffs/${created.handoffId}/decision`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
      body: JSON.stringify({ allow: true })
    });

    // 用户上传图片
    const imageData = Buffer.from('fake-png-content').toString('base64');
    const upload = await fetch(`${base}/api/chat/handoff/${created.handoffId}/message`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        attachment: { name: 'screenshot.png', mime: 'image/png', data: imageData }
      })
    });
    assert.equal(upload.status, 200);
    const uploadBody = await upload.json();
    const imageMessage = uploadBody.handoff.messages.at(-1);
    assert.equal(imageMessage.attachment.name, 'screenshot.png');
    assert.equal(imageMessage.attachment.mime, 'image/png');
    assert.equal(imageMessage.attachment.data, imageData);

    // 管理员上传文件
    const fileData = Buffer.from('log-content').toString('base64');
    const adminUpload = await fetch(`${base}/api/admin/handoffs/${created.handoffId}/message`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
      body: JSON.stringify({
        attachment: { name: 'debug.log', mime: 'text/plain', data: fileData }
      })
    });
    assert.equal(adminUpload.status, 200);

    // 用户结束对话
    const close = await fetch(`${base}/api/chat/handoff/${created.handoffId}/close`, {
      method: 'POST'
    });
    assert.equal(close.status, 200);
    const closeBody = await close.json();
    assert.equal(closeBody.handoff.status, 'closed');
    assert.ok(closeBody.handoff.messages.some((m) => m.text.includes('用户已结束对话')));
    assert.ok(closeBody.handoff.messages.some((m) => m.attachment?.name === 'debug.log'));

    // 结束后双方都不能继续发消息
    const userSend = await fetch(`${base}/api/chat/handoff/${created.handoffId}/message`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ text: '还能发吗' })
    });
    assert.equal(userSend.status, 409);
    const adminSend = await fetch(`${base}/api/admin/handoffs/${created.handoffId}/message`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
      body: JSON.stringify({ text: '还能发吗' })
    });
    assert.equal(adminSend.status, 409);
  } finally {
    await relay.close();
  }
});

test('chat returns handoff for transfer-to-human requests', async () => {
  const { relay, base } = await startChatServer({ deepseekApiKey: 'sk-test' });
  try {
    const res = await postJson(base, { message: '我要转人工' });
    const data = await res.json();
    assert.equal(data.type, 'handoff');
    assert.match(data.reply, /人工/);
  } finally {
    await relay.close();
  }
});

test('chat returns 503 when remote question asked without API key', async () => {
  const { relay, base } = await startChatServer({ deepseekApiKey: '' });
  try {
    const res = await postJson(base, { message: '远控连接失败了，为什么？' });
    assert.equal(res.status, 503);
    const data = await res.json();
    assert.equal(data.type, 'unavailable');
  } finally {
    await relay.close();
  }
});

test('chat answers remote questions via DeepSeek', async () => {
  let received = null;
  const { relay, base } = await startChatServer({
    deepseekApiKey: 'sk-test',
    chatFetch: async (url, init) => {
      received = JSON.parse(init.body);
      return new Response(
        JSON.stringify({
          choices: [{ message: { role: 'assistant', content: '请检查服务器地址和配对码是否正确。' } }]
        }),
        { status: 200, headers: { 'content-type': 'application/json' } }
      );
    }
  });
  try {
    const res = await postJson(base, { message: '远控连接失败了，为什么？' });
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.equal(data.type, 'reply');
    assert.match(data.reply, /服务器/);
    assert.equal(received.model, 'deepseek-chat');
    assert.ok(received.max_tokens <= 300);
    assert.equal(received.messages[0].role, 'system');
  } finally {
    await relay.close();
  }
});

test('chat rate limits by IP', async () => {
  const { relay, base } = await startChatServer({
    deepseekApiKey: 'sk-test',
    chatRateLimit: 2
  });
  try {
    const send = () => postJson(base, { message: '1+1等于几？' });
    assert.equal((await send()).status, 200);
    assert.equal((await send()).status, 200);
    const res = await send();
    assert.equal(res.status, 429);
  } finally {
    await relay.close();
  }
});

async function startConsoleServer(options = {}) {
  const fs = await import('node:fs/promises');
  const os = await import('node:os');
  const path = await import('node:path');
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), 'palmstore-'));
  const adminDir = await fs.mkdtemp(path.join(os.tmpdir(), 'palmadmin-'));
  await fs.writeFile(path.join(adminDir, 'index.html'), '<h1>PalmControl 后台</h1>');
  const relay = createRelayServer({ roomTtlMs: 60_000, dataDir, adminDir, adminPort: 0, ...options });
  const address = await relay.listen(0, '127.0.0.1');
  return { relay, base: `http://127.0.0.1:${address.port}` };
}

async function call(base, method, path, body, token) {
  const headers = { 'content-type': 'application/json' };
  if (token) headers.authorization = `Bearer ${token}`;
  return fetch(`${base}${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body)
  });
}

test('accounts register, login and keep email on the server', async () => {
  const { relay, base } = await startConsoleServer();
  try {
    const missingEmail = await call(base, 'POST', '/api/auth/register', {
      username: 'alice',
      password: 'secret123'
    });
    assert.equal(missingEmail.status, 400);
    assert.equal((await missingEmail.json()).error, 'email_required');

    const created = await call(base, 'POST', '/api/auth/register', {
      username: 'alice',
      email: 'alice@example.com',
      password: 'secret123'
    });
    assert.equal(created.status, 200);
    const data = await created.json();
    assert.ok(data.token);
    assert.equal(data.user.email, 'alice@example.com');

    const duplicate = await call(base, 'POST', '/api/auth/register', {
      username: 'Alice',
      email: 'other@example.com',
      password: 'secret123'
    });
    assert.equal(duplicate.status, 409);

    const wrong = await call(base, 'POST', '/api/auth/login', {
      username: 'alice',
      password: 'nope'
    });
    assert.equal(wrong.status, 401);

    const login = await call(base, 'POST', '/api/auth/login', {
      username: 'alice',
      password: 'secret123'
    });
    assert.equal(login.status, 200);
    const session = await login.json();

    const me = await call(base, 'GET', '/api/auth/me', undefined, session.token);
    assert.equal(me.status, 200);
    assert.equal((await me.json()).user.email, 'alice@example.com');

    const legacy = await call(base, 'POST', '/api/auth/register', {
      username: 'olduser',
      password: 'secret123',
      migrate: true
    });
    assert.equal(legacy.status, 200);
    assert.equal((await legacy.json()).user.email, '');
  } finally {
    await relay.close();
  }
});

test('console lists users, bans and unbans them, and delivers inbox messages', async () => {
  const { relay, base } = await startConsoleServer();
  try {
    const badLogin = await call(base, 'POST', '/api/console/login', {
      username: 'ADMIN',
      password: 'ADMIN123'
    });
    assert.equal(badLogin.status, 401);

    const login = await call(base, 'POST', '/api/console/login', {
      username: 'ADMIN',
      password: 'admin123'
    });
    assert.equal(login.status, 200);
    const { token: consoleToken } = await login.json();

    const registered = await call(base, 'POST', '/api/auth/register', {
      username: 'bob',
      email: 'bob@example.com',
      password: 'secret123'
    });
    const userToken = (await registered.json()).token;

    const list = await call(base, 'GET', '/api/console/users?query=bob', undefined, consoleToken);
    assert.equal(list.status, 200);
    const users = (await list.json()).users;
    assert.equal(users.length, 1);
    assert.equal(users[0].email, 'bob@example.com');

    const sent = await call(base, 'POST', '/api/console/users/bob/message', {
      title: '维护通知',
      body: '今晚 10 点升级'
    }, consoleToken);
    assert.equal(sent.status, 200);

    const inboxRes = await call(base, 'GET', '/api/messages', undefined, userToken);
    assert.equal(inboxRes.status, 200);
    const inbox = await inboxRes.json();
    assert.equal(inbox.unread, 1);
    assert.equal(inbox.messages[0].body, '今晚 10 点升级');

    const read = await call(
      base,
      'POST',
      `/api/messages/${inbox.messages[0].id}/read`,
      {},
      userToken
    );
    assert.equal(read.status, 200);
    const afterRead = await (await call(base, 'GET', '/api/messages', undefined, userToken)).json();
    assert.equal(afterRead.unread, 0);

    const unauthorized = await call(base, 'GET', '/api/console/overview');
    assert.equal(unauthorized.status, 401);

    const overviewRes = await call(base, 'GET', '/api/console/overview', undefined, consoleToken);
    assert.equal(overviewRes.status, 200);
    const overview = await overviewRes.json();
    assert.equal(overview.server.users, 1);
    assert.ok(overview.server.memory.totalBytes > 0);
    assert.ok(overview.server.cpuPercent >= 0 && overview.server.cpuPercent <= 100);
    assert.ok(overview.server.traffic.inBytes >= 0);
    assert.ok(Array.isArray(overview.connections));
    assert.equal(overview.nodes.length, 1);
    assert.equal(overview.nodes[0].online, true);
    assert.ok(overview.nodes[0].latencyMs >= 0);

    const announced = await call(
      base,
      'POST',
      '/api/console/announce',
      { title: '版本公告', body: '1.1.2 已发布' },
      consoleToken
    );
    assert.equal(announced.status, 200);
    assert.equal((await announced.json()).count, 1);

    const afterAnnounce = await (await call(base, 'GET', '/api/messages', undefined, userToken)).json();
    assert.equal(afterAnnounce.unread, 1);
    assert.equal(afterAnnounce.messages.length, 2);
    assert.equal(afterAnnounce.messages[1].title, '版本公告');
    assert.equal(afterAnnounce.messages[1].from, 'announcement');

    const ban = await call(base, 'POST', '/api/console/users/bob/ban', { banned: true }, consoleToken);
    assert.equal(ban.status, 200);
    assert.equal((await ban.json()).user.banned, true);

    const bannedInbox = await call(base, 'GET', '/api/messages', undefined, userToken);
    assert.equal(bannedInbox.status, 200);
    const bannedLogin = await call(base, 'POST', '/api/auth/login', {
      username: 'bob',
      password: 'secret123'
    });
    assert.equal(bannedLogin.status, 200);
    assert.equal((await bannedLogin.json()).user.banned, true);

    const unban = await call(base, 'POST', '/api/console/users/bob/ban', { banned: false }, consoleToken);
    assert.equal(unban.status, 200);
    const loginAgain = await call(base, 'POST', '/api/auth/login', {
      username: 'bob',
      password: 'secret123'
    });
    assert.equal(loginAgain.status, 200);
  } finally {
    await relay.close();
  }
});

test('banned users keep login and messages but lose remote control and support', async () => {
  const { relay, base } = await startConsoleServer();
  try {
    const registered = await call(base, 'POST', '/api/auth/register', {
      username: 'carol',
      email: 'carol@example.com',
      password: 'secret123'
    });
    const { token: userToken } = await registered.json();
    const consoleLogin = await call(base, 'POST', '/api/console/login', {
      username: 'ADMIN',
      password: 'admin123'
    });
    const { token: consoleToken } = await consoleLogin.json();
    await call(base, 'POST', '/api/console/users/carol/ban', { banned: true }, consoleToken);

    // 登录、消息公告正常
    const login = await call(base, 'POST', '/api/auth/login', {
      username: 'carol',
      password: 'secret123'
    });
    assert.equal(login.status, 200);
    const loginData = await login.json();
    assert.equal(loginData.user.banned, true);
    assert.equal(
      (await call(base, 'GET', '/api/messages', undefined, loginData.token)).status,
      200
    );

    // 客服与转人工被拦截
    const chat = await call(base, 'POST', '/api/chat', {
      messages: [{ role: 'user', content: '转人工' }],
      userName: 'carol'
    }, loginData.token);
    assert.equal(chat.status, 403);
    assert.equal((await chat.json()).reply, '账号已被限制使用');

    // 远控信令握手被拒绝
    const wsUrl = `${base.replace('http', 'ws')}/ws?token=${loginData.token}`;
    const ws = new WebSocket(wsUrl);
    const message = waitJson(ws);
    const closed = once(ws, 'close');
    await once(ws, 'open');
    const rejected = await message;
    assert.equal(rejected.type, 'error');
    assert.equal(rejected.code, 'banned');
    await closed;
  } finally {
    await relay.close();
  }
});

test('console sends email when configured and reports missing smtp otherwise', async () => {
  const mails = [];
  const { relay, base } = await startConsoleServer({
    sendMail: async (mail) => {
      mails.push(mail);
      return { accepted: [mail.to] };
    }
  });
  try {
    await call(base, 'POST', '/api/auth/register', {
      username: 'carol',
      email: 'carol@example.com',
      password: 'secret123'
    });
    const { token } = await (await call(base, 'POST', '/api/console/login', {
      username: 'ADMIN',
      password: 'admin123'
    })).json();

    const sent = await call(base, 'POST', '/api/console/users/carol/email', {
      subject: '账号提醒',
      body: '请及时更新密码'
    }, token);
    assert.equal(sent.status, 200);
    assert.equal(mails.length, 1);
    assert.equal(mails[0].to, 'carol@example.com');

    const page = await fetch(`${base}/admin`);
    assert.equal(page.status, 200);
    assert.match(await page.text(), /PalmControl/);
  } finally {
    await relay.close();
  }
});

test('console email returns 503 when no smtp is configured', async () => {
  const { relay, base } = await startConsoleServer();
  try {
    await call(base, 'POST', '/api/auth/register', {
      username: 'dave',
      email: 'dave@example.com',
      password: 'secret123'
    });
    const { token } = await (await call(base, 'POST', '/api/console/login', {
      username: 'ADMIN',
      password: 'admin123'
    })).json();
    const res = await call(base, 'POST', '/api/console/users/dave/email', {
      subject: 'hi',
      body: 'hello'
    }, token);
    assert.equal(res.status, 503);
    assert.equal((await res.json()).error, 'smtp_not_configured');
  } finally {
    await relay.close();
  }
});

test('console runs on its own port while relay keeps another', async () => {
  const { relay, base } = await startConsoleServer();
  try {
    const consolePort = relay.adminServer.address().port;
    assert.ok(consolePort > 0);
    assert.notEqual(consolePort, relay.httpServer.address().port);

    const page = await fetch(`http://127.0.0.1:${consolePort}/admin`);
    assert.equal(page.status, 200);
    assert.match(await page.text(), /PalmControl/);

    const health = await (await fetch(`http://127.0.0.1:${consolePort}/health`)).json();
    assert.equal(health.adminPort, consolePort);

    // 中继端口照常提供 App 接口
    const relayHealth = await (await fetch(`${base}/health`)).json();
    assert.equal(relayHealth.ok, true);
    assert.equal(relayHealth.adminPort, consolePort);
  } finally {
    await relay.close();
  }
});
